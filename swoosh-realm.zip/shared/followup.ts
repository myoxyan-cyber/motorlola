export interface FollowUpRecord {
  id: string;
  tanggal: string; // ISO date string
  userId: string;
  namaRekening: string;
  noWa: string;
  kataKata: string; // WhatsApp message for follow-up
  statusWa: 'aktif' | 'tidak aktif';
  namaCS: string;
  fotoBukti?: string; // Photo URL from Supabase Storage
  createdAt: string;
  updatedAt: string;
}

export interface CreateFollowUpRequest {
  tanggal: string;
  userId: string;
  namaRekening: string;
  noWa: string;
  kataKata: string; // WhatsApp message for follow-up
  statusWa?: 'aktif' | 'tidak aktif';
  namaCS?: string;
  fotoBukti?: string;
}

export interface UpdateFollowUpRequest {
  statusWa?: 'aktif' | 'tidak aktif';
  namaCS?: string;
  fotoBukti?: string;
}

export interface BulkCreateFollowUpRequest {
  records: CreateFollowUpRequest[];
}

export interface FollowUpResponse {
  success: boolean;
  data?: FollowUpRecord | FollowUpRecord[];
  message?: string;
}

export interface DashboardStats {
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  pendingFollowUp: number;
  completedToday: number;
}
