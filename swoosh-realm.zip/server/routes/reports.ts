import { RequestHandler } from "express";
import { supabase, DatabaseRow } from "../lib/supabase";
import { z } from "zod";

// Validation schemas
const reportsQuerySchema = z.object({
  start: z.string().optional(),
  end: z.string().optional(),
});

interface ReportData {
  daily: DailyReport[];
  weekly: WeeklyReport[];
  monthly: MonthlyReport[];
  yearly: YearlyReport[];
  summary: ReportSummary;
}

interface DailyReport {
  date: string;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface WeeklyReport {
  week: string;
  weekNumber: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface MonthlyReport {
  month: string;
  year: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface YearlyReport {
  year: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface ReportSummary {
  totalRecords: number;
  totalActiveWa: number;
  totalInactiveWa: number;
  totalCompleted: number;
  totalPending: number;
  completionRate: number;
  activeRate: number;
}

// Helper function to get date range
const getDateRange = (start?: string, end?: string) => {
  const endDate = end ? new Date(end) : new Date();
  const startDate = start ? new Date(start) : new Date(Date.now() - 30 * 24 * 60 * 60 * 1000); // 30 days ago

  return {
    start: startDate.toISOString().split('T')[0],
    end: endDate.toISOString().split('T')[0]
  };
};

// Helper function to format date for SQL
const formatDateForSQL = (date: string) => {
  return new Date(date).toISOString();
};

// Helper function to get week number
const getWeekNumber = (date: Date) => {
  const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
  const pastDaysOfYear = (date.getTime() - firstDayOfYear.getTime()) / 86400000;
  return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
};

// Helper function to get month name in Indonesian
const getMonthName = (monthIndex: number) => {
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  return months[monthIndex];
};

// Get reports data
export const getReports: RequestHandler = async (req, res) => {
  try {
    const validatedQuery = reportsQuerySchema.parse(req.query);
    const { start, end } = getDateRange(validatedQuery.start, validatedQuery.end);

    // Fetch all records within date range
    const { data: records, error } = await supabase
      .from('follow_up_records')
      .select('*')
      .gte('tanggal', formatDateForSQL(start))
      .lte('tanggal', formatDateForSQL(end))
      .order('tanggal', { ascending: true });

    if (error) {
      return res.status(500).json({
        success: false,
        message: 'Error fetching records: ' + error.message
      });
    }

    const reportData = generateReportData(records || []);

    res.json({
      success: true,
      data: reportData
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      });
    }
    
    console.error('Reports error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Generate report data from records
const generateReportData = (records: DatabaseRow[]): ReportData => {
  // Group records by different time periods
  const dailyGroups = new Map<string, DatabaseRow[]>();
  const weeklyGroups = new Map<string, DatabaseRow[]>();
  const monthlyGroups = new Map<string, DatabaseRow[]>();
  const yearlyGroups = new Map<number, DatabaseRow[]>();

  records.forEach(record => {
    const date = new Date(record.tanggal);
    
    // Daily grouping
    const dayKey = date.toISOString().split('T')[0];
    if (!dailyGroups.has(dayKey)) {
      dailyGroups.set(dayKey, []);
    }
    dailyGroups.get(dayKey)!.push(record);

    // Weekly grouping
    const year = date.getFullYear();
    const weekNumber = getWeekNumber(date);
    const weekKey = `${year}-W${weekNumber.toString().padStart(2, '0')}`;
    if (!weeklyGroups.has(weekKey)) {
      weeklyGroups.set(weekKey, []);
    }
    weeklyGroups.get(weekKey)!.push(record);

    // Monthly grouping
    const monthKey = `${year}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
    if (!monthlyGroups.has(monthKey)) {
      monthlyGroups.set(monthKey, []);
    }
    monthlyGroups.get(monthKey)!.push(record);

    // Yearly grouping
    if (!yearlyGroups.has(year)) {
      yearlyGroups.set(year, []);
    }
    yearlyGroups.get(year)!.push(record);
  });

  // Generate daily reports
  const daily: DailyReport[] = Array.from(dailyGroups.entries()).map(([date, dayRecords]) => {
    const stats = calculateStats(dayRecords);
    return {
      date,
      ...stats
    };
  });

  // Generate weekly reports
  const weekly: WeeklyReport[] = Array.from(weeklyGroups.entries()).map(([week, weekRecords]) => {
    const stats = calculateStats(weekRecords);
    const [year, weekPart] = week.split('-W');
    const weekNumber = parseInt(weekPart);
    
    return {
      week: `Minggu ${weekNumber}, ${year}`,
      weekNumber,
      ...stats
    };
  });

  // Generate monthly reports
  const monthly: MonthlyReport[] = Array.from(monthlyGroups.entries()).map(([month, monthRecords]) => {
    const stats = calculateStats(monthRecords);
    const [year, monthNum] = month.split('-');
    const monthName = getMonthName(parseInt(monthNum) - 1);
    
    return {
      month: `${monthName} ${year}`,
      year: parseInt(year),
      ...stats
    };
  });

  // Generate yearly reports
  const yearly: YearlyReport[] = Array.from(yearlyGroups.entries()).map(([year, yearRecords]) => {
    const stats = calculateStats(yearRecords);
    
    return {
      year,
      ...stats
    };
  });

  // Generate summary
  const summary = calculateSummary(records);

  return {
    daily,
    weekly,
    monthly,
    yearly,
    summary
  };
};

// Calculate statistics for a group of records
const calculateStats = (records: DatabaseRow[]) => {
  const totalRecords = records.length;
  const activeWa = records.filter(r => r.status_wa === 'aktif').length;
  const inactiveWa = records.filter(r => r.status_wa === 'tidak aktif').length;
  const completedFollowUps = records.filter(r => r.nama_cs && r.nama_cs.trim() !== '').length;
  const pendingFollowUps = records.filter(r => !r.nama_cs || r.nama_cs.trim() === '').length;

  return {
    totalRecords,
    activeWa,
    inactiveWa,
    completedFollowUps,
    pendingFollowUps
  };
};

// Calculate overall summary
const calculateSummary = (records: DatabaseRow[]): ReportSummary => {
  const totalRecords = records.length;
  const totalActiveWa = records.filter(r => r.status_wa === 'aktif').length;
  const totalInactiveWa = records.filter(r => r.status_wa === 'tidak aktif').length;
  const totalCompleted = records.filter(r => r.nama_cs && r.nama_cs.trim() !== '').length;
  const totalPending = records.filter(r => !r.nama_cs || r.nama_cs.trim() === '').length;

  const completionRate = totalRecords > 0 ? (totalCompleted / totalRecords) * 100 : 0;
  const activeRate = totalRecords > 0 ? (totalActiveWa / totalRecords) * 100 : 0;

  return {
    totalRecords,
    totalActiveWa,
    totalInactiveWa,
    totalCompleted,
    totalPending,
    completionRate,
    activeRate
  };
};

// Get CS performance reports
export const getCSPerformance: RequestHandler = async (req, res) => {
  try {
    const validatedQuery = reportsQuerySchema.parse(req.query);
    const { start, end } = getDateRange(validatedQuery.start, validatedQuery.end);

    // Fetch records with CS data
    const { data: records, error } = await supabase
      .from('follow_up_records')
      .select('*')
      .gte('tanggal', formatDateForSQL(start))
      .lte('tanggal', formatDateForSQL(end))
      .not('nama_cs', 'is', null)
      .not('nama_cs', 'eq', '')
      .order('tanggal', { ascending: true });

    if (error) {
      return res.status(500).json({
        success: false,
        message: 'Error fetching CS performance: ' + error.message
      });
    }

    // Group by CS
    const csGroups = new Map<string, DatabaseRow[]>();
    
    (records || []).forEach(record => {
      const csName = record.nama_cs.trim();
      if (csName) {
        if (!csGroups.has(csName)) {
          csGroups.set(csName, []);
        }
        csGroups.get(csName)!.push(record);
      }
    });

    const csPerformance = Array.from(csGroups.entries()).map(([csName, csRecords]) => {
      const stats = calculateStats(csRecords);
      return {
        csName,
        ...stats
      };
    }).sort((a, b) => b.totalRecords - a.totalRecords);

    res.json({
      success: true,
      data: csPerformance
    });
  } catch (error) {
    console.error('CS Performance error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};
