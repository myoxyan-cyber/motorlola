import { RequestHandler } from "express";
import { supabase } from "../lib/supabase";
import { z } from "zod";
import bcrypt from "bcrypt";

// Validation schemas
const createUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  name: z.string().min(1, "Name is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.enum(['admin', 'cs']).default('cs'),
});

const updateUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters").optional(),
  name: z.string().min(1, "Name is required").optional(),
  password: z.string().min(6, "Password must be at least 6 characters").optional(),
  role: z.enum(['admin', 'cs']).optional(),
});

// Database types
interface DatabaseUserRow {
  id: string;
  username: string;
  name: string;
  password_hash: string;
  role: 'admin' | 'cs';
  created_at: string;
  updated_at: string;
}

// Helper function to convert database row to user object
const convertToUser = (row: DatabaseUserRow) => ({
  id: row.id,
  username: row.username,
  name: row.name,
  role: row.role,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

// Get all users
export const getAllUsers: RequestHandler = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(500).json({
        success: false,
        message: 'Error fetching users: ' + error.message
      });
    }

    const users = data.map(convertToUser);
    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Get single user
export const getUser: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      return res.status(error.code === 'PGRST116' ? 404 : 500).json({
        success: false,
        message: error.code === 'PGRST116' ? 'User not found' : 'Error fetching user: ' + error.message
      });
    }

    const user = convertToUser(data);
    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Create new user
export const createUser: RequestHandler = async (req, res) => {
  try {
    const validatedData = createUserSchema.parse(req.body);
    
    // Hash the password
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(validatedData.password, saltRounds);
    
    const { data, error } = await supabase
      .from('users')
      .insert({
        username: validatedData.username,
        name: validatedData.name,
        password_hash: passwordHash,
        role: validatedData.role,
      })
      .select()
      .single();

    if (error) {
      if (error.code === '23505') { // Unique constraint violation
        return res.status(400).json({
          success: false,
          message: 'Username already exists'
        });
      }
      
      return res.status(500).json({
        success: false,
        message: 'Error creating user: ' + error.message
      });
    }

    const user = convertToUser(data);
    res.status(201).json({
      success: true,
      data: user,
      message: 'User created successfully'
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      });
    }
    
    console.error('Error creating user:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Update user
export const updateUser: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const validatedData = updateUserSchema.parse(req.body);
    
    const updateData: any = {};
    if (validatedData.username) updateData.username = validatedData.username;
    if (validatedData.name) updateData.name = validatedData.name;
    if (validatedData.role) updateData.role = validatedData.role;
    
    // Hash new password if provided
    if (validatedData.password) {
      const saltRounds = 10;
      updateData.password_hash = await bcrypt.hash(validatedData.password, saltRounds);
    }

    const { data, error } = await supabase
      .from('users')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      if (error.code === '23505') { // Unique constraint violation
        return res.status(400).json({
          success: false,
          message: 'Username already exists'
        });
      }
      
      return res.status(error.code === 'PGRST116' ? 404 : 500).json({
        success: false,
        message: error.code === 'PGRST116' ? 'User not found' : 'Error updating user: ' + error.message
      });
    }

    const user = convertToUser(data);
    res.json({
      success: true,
      data: user,
      message: 'User updated successfully'
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      });
    }
    
    console.error('Error updating user:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Delete user
export const deleteUser: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    
    const { error } = await supabase
      .from('users')
      .delete()
      .eq('id', id);

    if (error) {
      return res.status(500).json({
        success: false,
        message: 'Error deleting user: ' + error.message
      });
    }

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};
