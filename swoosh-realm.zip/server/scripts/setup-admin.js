const { createClient } = require('@supabase/supabase-js');
const bcrypt = require('bcrypt');

// Supabase config
const supabaseUrl = 'https://xjgldkdnooyuefzwdmxn.supabase.co';
const supabaseServiceKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhqZ2xka2Rub295dWVmendkbXhuIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNjM3OTg2NCwiZXhwIjoyMDUxOTU1ODY0fQ.VfpN3NbzGZ5pJdX4S4OMOmHznD4_OZWBe8GtNY6-A6k';

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function setupAdmin() {
  try {
    console.log('🔍 Checking existing users...');
    
    // Check existing users
    const { data: users, error: fetchError } = await supabase
      .from('users')
      .select('*');
    
    if (fetchError) {
      console.error('❌ Error fetching users:', fetchError);
      return;
    }
    
    console.log('📋 Current users:', users);
    
    // If no users exist, create admin
    if (!users || users.length === 0) {
      console.log('👤 No users found. Creating admin user...');
      
      const passwordHash = await bcrypt.hash('admin123', 10);
      
      const { data: newUser, error: createError } = await supabase
        .from('users')
        .insert({
          username: 'admin',
          name: 'Administrator',
          password_hash: passwordHash,
          role: 'admin'
        })
        .select()
        .single();
      
      if (createError) {
        console.error('❌ Error creating admin:', createError);
        return;
      }
      
      console.log('✅ Admin user created successfully!');
      console.log('📝 Login credentials:');
      console.log('   Username: admin');
      console.log('   Password: admin123');
      
    } else {
      console.log('✅ Users already exist in database');
      console.log('📝 Existing users:');
      users.forEach(user => {
        console.log(`   - ${user.username} (${user.name}) - Role: ${user.role}`);
      });
    }
    
  } catch (error) {
    console.error('❌ Setup error:', error);
  }
}

setupAdmin();
