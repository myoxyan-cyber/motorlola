import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import {
  Upload,
  Download,
  Search,
  Edit2,
  Save,
  X,
  FileImage,
  Trash2,
  RefreshCw,
  Eye,
  ImageIcon,
  MessageCircle,
  ExternalLink,
  Copy,
  Users,
  CheckSquare
} from "lucide-react";
import { FollowUpRecord } from "@shared/followup";

interface EditingRow {
  id: string;
  statusWa: 'aktif' | 'tidak aktif';
  namaCS: string;
}

export default function Database() {
  const [data, setData] = useState<FollowUpRecord[]>([]);
  const [filteredData, setFilteredData] = useState<FollowUpRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingRows, setEditingRows] = useState<Map<string, EditingRow>>(new Map());
  const [draggedOver, setDraggedOver] = useState<string | null>(null);
  const [viewingPhoto, setViewingPhoto] = useState<{ recordId: string; photoUrl: string; recordName: string } | null>(null);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [bulkUpdateData, setBulkUpdateData] = useState<{ namaCS: string; statusWa: 'aktif' | 'tidak aktif' | 'unchanged' }>({ namaCS: '', statusWa: 'unchanged' });
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const fileInputRefs = useRef<Map<string, HTMLInputElement>>(new Map());

  // Fetch data from API
  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/followups');
      const result = await response.json();
      if (result.success) {
        setData(result.data);
        setFilteredData(result.data);
      } else {
        toast.error("Gagal mengambil data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat mengambil data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Filter data based on search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredData(data);
    } else {
      const filtered = data.filter(row =>
        row.namaRekening.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.userId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.noWa.includes(searchTerm) ||
        row.namaCS.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.kataKata.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredData(filtered);
    }
  }, [searchTerm, data]);

  // Start editing a row
  const startEditing = (record: FollowUpRecord) => {
    const newEditingRows = new Map(editingRows);
    newEditingRows.set(record.id, {
      id: record.id,
      statusWa: record.statusWa,
      namaCS: record.namaCS,
    });
    setEditingRows(newEditingRows);
  };

  // Cancel editing
  const cancelEditing = (id: string) => {
    const newEditingRows = new Map(editingRows);
    newEditingRows.delete(id);
    setEditingRows(newEditingRows);
  };

  // Update editing row data
  const updateEditingRow = (id: string, field: keyof EditingRow, value: string) => {
    const newEditingRows = new Map(editingRows);
    const currentRow = newEditingRows.get(id);
    if (currentRow) {
      newEditingRows.set(id, { ...currentRow, [field]: value });
      setEditingRows(newEditingRows);
    }
  };

  // Save changes
  const saveChanges = async (id: string) => {
    const editingRow = editingRows.get(id);
    if (!editingRow) return;

    try {
      const response = await fetch(`/api/followups/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          statusWa: editingRow.statusWa,
          namaCS: editingRow.namaCS,
        }),
      });

      const result = await response.json();
      if (result.success) {
        // Refresh data from server to ensure full sync
        await fetchData();
        cancelEditing(id);
        toast.success("Data berhasil disimpan");
      } else {
        toast.error(result.message || "Gagal menyimpan data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menyimpan data");
    }
  };

  // Handle file upload
  const handleFileUpload = async (recordId: string, file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error("File harus berupa gambar");
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast.error("Ukuran file maksimal 5MB");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;

      try {
        const response = await fetch('/api/followups/upload-photo', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            recordId,
            photoData: base64,
          }),
        });

        const result = await response.json();
        if (result.success) {
          // Refresh data from server to get the correct photo URL
          await fetchData();
          toast.success("Foto berhasil diupload");
        } else {
          toast.error(result.message || "Gagal mengupload foto");
        }
      } catch (error) {
        toast.error("Terjadi kesalahan saat mengupload foto");
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent, recordId: string) => {
    e.preventDefault();
    setDraggedOver(recordId);
  };

  const handleDragLeave = () => {
    setDraggedOver(null);
  };

  const handleDrop = (e: React.DragEvent, recordId: string) => {
    e.preventDefault();
    setDraggedOver(null);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(recordId, files[0]);
    }
  };

  // Delete record
  const deleteRecord = async (id: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus data ini?")) return;

    try {
      const response = await fetch(`/api/followups/${id}`, {
        method: 'DELETE',
      });

      const result = await response.json();
      if (result.success) {
        // Refresh data from server to ensure consistency
        await fetchData();
        toast.success("Data berhasil dihapus");
      } else {
        toast.error(result.message || "Gagal menghapus data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menghapus data");
    }
  };

  // Delete photo
  const deletePhoto = async (recordId: string) => {
    if (!confirm("Apakah Anda yakin ingin menghapus foto bukti ini?")) return;

    try {
      const response = await fetch('/api/followups/upload-photo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recordId,
          photoData: null,
        }),
      });

      const result = await response.json();
      if (result.success) {
        // Refresh data from server to ensure UI sync
        await fetchData();
        setViewingPhoto(null);
        toast.success("Foto berhasil dihapus");
      } else {
        toast.error(result.message || "Gagal menghapus foto");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menghapus foto");
    }
  };

  // View photo in modal
  const viewPhoto = (recordId: string, photoUrl: string, recordName: string) => {
    setViewingPhoto({ recordId, photoUrl, recordName });
  };

  // Handle row selection
  const toggleRowSelection = (recordId: string) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(recordId)) {
      newSelected.delete(recordId);
    } else {
      newSelected.add(recordId);
    }
    setSelectedRows(newSelected);
  };

  // Handle select all
  const toggleSelectAll = () => {
    if (selectedRows.size === filteredData.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(filteredData.map(record => record.id)));
    }
  };

  // Bulk delete selected records
  const bulkDeleteRecords = async () => {
    const selectedIds = Array.from(selectedRows);
    if (selectedIds.length === 0) {
      toast.error("Pilih data yang ingin dihapus");
      return;
    }

    if (!confirm(`Apakah Anda yakin ingin menghapus ${selectedIds.length} data yang dipilih?`)) {
      return;
    }

    try {
      const response = await fetch('/api/followups/bulk-delete', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ids: selectedIds }),
      });

      const result = await response.json();
      if (result.success) {
        await fetchData();
        setSelectedRows(new Set());
        toast.success(`${selectedIds.length} data berhasil dihapus`);
      } else {
        toast.error(result.message || "Gagal menghapus data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menghapus data");
    }
  };

  // Bulk update selected records
  const bulkUpdateRecords = async () => {
    const selectedIds = Array.from(selectedRows);
    if (selectedIds.length === 0) {
      toast.error("Pilih data yang ingin diupdate");
      return;
    }

    if (!bulkUpdateData.namaCS && bulkUpdateData.statusWa === 'unchanged') {
      toast.error("Masukkan data yang ingin diupdate");
      return;
    }

    try {
      const updatePayload: any = { ids: selectedIds };
      if (bulkUpdateData.namaCS) updatePayload.namaCS = bulkUpdateData.namaCS;
      if (bulkUpdateData.statusWa && bulkUpdateData.statusWa !== 'unchanged') updatePayload.statusWa = bulkUpdateData.statusWa;

      const response = await fetch('/api/followups/bulk-update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatePayload),
      });

      const result = await response.json();
      if (result.success) {
        await fetchData();
        setSelectedRows(new Set());
        setShowBulkUpdate(false);
        setBulkUpdateData({ namaCS: '', statusWa: 'unchanged' });
        toast.success(`${selectedIds.length} data berhasil diupdate`);
      } else {
        toast.error(result.message || "Gagal mengupdate data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat mengupdate data");
    }
  };

  // Bulk copy WhatsApp links
  const bulkCopyWhatsAppLinks = async () => {
    const selectedIds = Array.from(selectedRows);
    if (selectedIds.length === 0) {
      toast.error("Pilih data yang ingin dicopy link WhatsApp-nya");
      return;
    }

    const selectedRecords = filteredData.filter(record => selectedIds.includes(record.id));
    const links = selectedRecords
      .filter(record => record.kataKata && record.noWa)
      .map((record, index) => {
        const link = `https://wa.me/${record.noWa.replace(/^0/, '62')}?text=${encodeURIComponent(record.kataKata)}`;
        const info = `${index + 1}. ${record.nama || 'No Name'} (${record.noWa})`;
        return `${info}\n${link}`;
      })
      .join('\n\n');

    if (links.length === 0) {
      toast.error("Tidak ada link WhatsApp yang bisa dicopy dari data yang dipilih");
      return;
    }

    try {
      await navigator.clipboard.writeText(links);
      toast.success(`${selectedRecords.filter(r => r.kataKata && r.noWa).length} link WhatsApp berhasil dicopy ke clipboard`);
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = links;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      toast.success(`${selectedRecords.filter(r => r.kataKata && r.noWa).length} link WhatsApp berhasil dicopy ke clipboard`);
    }
  };

  // Export to CSV
  const exportToCsv = () => {
    const csvContent = [
      ['Tanggal', 'User ID', 'Nama Rekening', 'No WA', 'Kata Kata', 'Status WA', 'Nama CS'],
      ...filteredData.map(row => [
        row.tanggal,
        row.userId,
        row.namaRekening,
        row.noWa,
        row.kataKata,
        row.statusWa,
        row.namaCS
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `database-followup-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Database Follow Up</h1>
          <p className="text-gray-600 mt-2">Kelola data follow up pelanggan</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            {filteredData.length} records
          </Badge>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Cari nama, user ID, nomor WA..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button onClick={fetchData} variant="outline" className="flex items-center space-x-2">
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </Button>
        </div>

        <div className="flex gap-3">
          <Button onClick={exportToCsv} variant="outline" className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </Button>
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedRows.size > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center space-x-4">
                <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300">
                  <CheckSquare className="h-4 w-4 mr-1" />
                  {selectedRows.size} data terpilih
                </Badge>

                <div className="flex gap-2">
                  <Button
                    onClick={bulkDeleteRecords}
                    variant="outline"
                    className="text-red-600 hover:text-red-800 hover:bg-red-50 border-red-200"
                    size="sm"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Hapus Terpilih
                  </Button>

                  <Button
                    onClick={() => setShowBulkUpdate(!showBulkUpdate)}
                    variant="outline"
                    className="text-blue-600 hover:text-blue-800 hover:bg-blue-50 border-blue-200"
                    size="sm"
                  >
                    <Users className="h-4 w-4 mr-2" />
                    Update Massal
                  </Button>

                  <Button
                    onClick={bulkCopyWhatsAppLinks}
                    variant="outline"
                    className="text-green-600 hover:text-green-800 hover:bg-green-50 border-green-200"
                    size="sm"
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Link WA
                  </Button>
                </div>
              </div>

              <Button
                onClick={() => setSelectedRows(new Set())}
                variant="ghost"
                size="sm"
              >
                <X className="h-4 w-4 mr-1" />
                Batal Pilih
              </Button>
            </div>

            {/* Bulk Update Form */}
            {showBulkUpdate && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-blue-200">
                <h4 className="text-sm font-medium text-gray-900 mb-3">Update Massal Data Terpilih</h4>
                <div className="flex flex-wrap gap-4 items-end">
                  <div className="flex-1 min-w-48">
                    <Label htmlFor="bulk-nama-cs" className="text-xs font-medium text-gray-700">Nama CS</Label>
                    <Input
                      id="bulk-nama-cs"
                      placeholder="Nama CS baru (opsional)"
                      value={bulkUpdateData.namaCS}
                      onChange={(e) => setBulkUpdateData(prev => ({ ...prev, namaCS: e.target.value }))}
                      className="mt-1"
                    />
                  </div>

                  <div className="flex-1 min-w-48">
                    <Label htmlFor="bulk-status-wa" className="text-xs font-medium text-gray-700">Status WA</Label>
                    <Select
                      value={bulkUpdateData.statusWa}
                      onValueChange={(value: 'aktif' | 'tidak aktif' | 'unchanged') =>
                        setBulkUpdateData(prev => ({ ...prev, statusWa: value as 'aktif' | 'tidak aktif' | '' }))
                      }
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Pilih status (opsional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unchanged">Tidak diubah</SelectItem>
                        <SelectItem value="aktif">Aktif</SelectItem>
                        <SelectItem value="tidak aktif">Tidak Aktif</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={bulkUpdateRecords}
                      className="bg-blue-600 hover:bg-blue-700"
                      size="sm"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Update {selectedRows.size} Data
                    </Button>
                    <Button
                      onClick={() => {
                        setShowBulkUpdate(false);
                        setBulkUpdateData({ namaCS: '', statusWa: 'unchanged' });
                      }}
                      variant="outline"
                      size="sm"
                    >
                      Batal
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Data Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-4 py-3 text-center text-sm font-medium text-gray-900">
                    <Checkbox
                      checked={selectedRows.size === filteredData.length && filteredData.length > 0}
                      onCheckedChange={toggleSelectAll}
                      aria-label="Pilih semua"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Tanggal</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">User ID</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Nama Rekening</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">No WA</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">WhatsApp Link</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Status WA</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Nama CS</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Foto Bukti</th>
                  <th className="px-4 py-3 text-center text-sm font-medium text-gray-900">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((record) => {
                  const isEditing = editingRows.has(record.id);
                  const editingRow = editingRows.get(record.id);

                  return (
                    <tr key={record.id} className={`border-b hover:bg-gray-50 ${selectedRows.has(record.id) ? 'bg-blue-50' : ''}`}>
                      <td className="px-4 py-3 text-center">
                        <Checkbox
                          checked={selectedRows.has(record.id)}
                          onCheckedChange={() => toggleRowSelection(record.id)}
                          aria-label={`Pilih data ${record.namaRekening}`}
                        />
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">
                        {new Date(record.tanggal).toLocaleDateString('id-ID')}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900">{record.userId}</td>
                      <td className="px-4 py-3 text-sm text-gray-900">{record.namaRekening}</td>
                      <td className="px-4 py-3 text-sm text-gray-900">{record.noWa}</td>

                      {/* WhatsApp Link */}
                      <td className="px-4 py-3">
                        {record.kataKata ? (
                          <div className="flex items-center space-x-2">
                            <a
                              href={`https://wa.me/${record.noWa.replace(/^0/, '62')}?text=${encodeURIComponent(record.kataKata)}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center space-x-1 text-green-600 hover:text-green-800 bg-green-50 hover:bg-green-100 px-2 py-1 rounded-lg transition-colors"
                              title={`Chat: ${record.kataKata}`}
                            >
                              <MessageCircle className="h-4 w-4" />
                              <span className="text-xs font-medium">Chat</span>
                              <ExternalLink className="h-3 w-3" />
                            </a>
                            <div className="text-xs text-gray-500 max-w-32 truncate" title={record.kataKata}>
                              {record.kataKata}
                            </div>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400 italic">Tidak ada pesan</span>
                        )}
                      </td>
                      
                      {/* Status WA - Editable */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Select
                            value={editingRow?.statusWa || record.statusWa}
                            onValueChange={(value: 'aktif' | 'tidak aktif') => 
                              updateEditingRow(record.id, 'statusWa', value)
                            }
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="aktif">Aktif</SelectItem>
                              <SelectItem value="tidak aktif">Tidak Aktif</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Badge variant={record.statusWa === 'aktif' ? 'default' : 'secondary'}>
                            {record.statusWa}
                          </Badge>
                        )}
                      </td>
                      
                      {/* Nama CS - Editable */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Input
                            value={editingRow?.namaCS || record.namaCS}
                            onChange={(e) => updateEditingRow(record.id, 'namaCS', e.target.value)}
                            placeholder="Nama CS"
                            className="w-32"
                          />
                        ) : (
                          <span className="text-sm text-gray-900">
                            {record.namaCS || '-'}
                          </span>
                        )}
                      </td>
                      
                      {/* Foto Bukti - Drag & Drop */}
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          <div
                            className={`relative w-16 h-16 border-2 border-dashed rounded-lg flex items-center justify-center cursor-pointer transition-colors ${
                              draggedOver === record.id
                                ? 'border-blue-400 bg-blue-50'
                                : 'border-gray-300 hover:border-gray-400'
                            }`}
                            onDragOver={(e) => handleDragOver(e, record.id)}
                            onDragLeave={handleDragLeave}
                            onDrop={(e) => handleDrop(e, record.id)}
                            onClick={() => {
                              if (!record.fotoBukti) {
                                const input = document.createElement('input');
                                input.type = 'file';
                                input.accept = 'image/*';
                                input.onchange = (e) => {
                                  const file = (e.target as HTMLInputElement).files?.[0];
                                  if (file) handleFileUpload(record.id, file);
                                };
                                input.click();
                              }
                            }}
                          >
                            {record.fotoBukti ? (
                              <img
                                src={record.fotoBukti}
                                alt="Bukti"
                                className="w-full h-full object-cover rounded cursor-pointer"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  viewPhoto(record.id, record.fotoBukti!, record.namaRekening);
                                }}
                              />
                            ) : (
                              <FileImage className="h-6 w-6 text-gray-400" />
                            )}
                          </div>

                          {/* Photo Actions */}
                          {record.fotoBukti && (
                            <div className="flex flex-col space-y-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => viewPhoto(record.id, record.fotoBukti!, record.namaRekening)}
                                className="h-8 w-8 p-0"
                                title="Lihat foto"
                              >
                                <Eye className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deletePhoto(record.id)}
                                className="h-8 w-8 p-0 text-red-600 hover:text-red-800 hover:bg-red-50"
                                title="Hapus foto"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          )}

                          {/* Upload new photo button */}
                          {record.fotoBukti && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                const input = document.createElement('input');
                                input.type = 'file';
                                input.accept = 'image/*';
                                input.onchange = (e) => {
                                  const file = (e.target as HTMLInputElement).files?.[0];
                                  if (file) handleFileUpload(record.id, file);
                                };
                                input.click();
                              }}
                              className="h-8 w-8 p-0"
                              title="Ganti foto"
                            >
                              <Upload className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </td>
                      
                      {/* Actions */}
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-2">
                          {isEditing ? (
                            <>
                              <Button
                                size="sm"
                                onClick={() => saveChanges(record.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Save className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => cancelEditing(record.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startEditing(record)}
                              >
                                <Edit2 className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteRecord(record.id)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredData.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">Tidak ada data yang ditemukan</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Photo Viewer Modal */}
      {viewingPhoto && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={() => setViewingPhoto(null)}>
          <div className="relative max-w-4xl max-h-[90vh] bg-white rounded-lg overflow-hidden" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b bg-gray-50">
              <div className="flex items-center space-x-3">
                <ImageIcon className="h-5 w-5 text-blue-600" />
                <div>
                  <h3 className="text-lg font-semibold">Foto Bukti</h3>
                  <p className="text-sm text-gray-600">{viewingPhoto.recordName}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => deletePhoto(viewingPhoto.recordId)}
                  className="text-red-600 hover:text-red-800 hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Hapus Foto
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setViewingPhoto(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-4">
              <img
                src={viewingPhoto.photoUrl}
                alt={`Foto bukti - ${viewingPhoto.recordName}`}
                className="max-w-full max-h-[70vh] object-contain mx-auto rounded"
              />
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between p-4 border-t bg-gray-50">
              <p className="text-sm text-gray-600">
                Klik di luar area ini atau tombol X untuk menutup
              </p>
              <Button
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/*';
                  input.onchange = (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0];
                    if (file) {
                      handleFileUpload(viewingPhoto.recordId, file);
                      setViewingPhoto(null);
                    }
                  };
                  input.click();
                }}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Upload className="h-4 w-4 mr-2" />
                Ganti Foto
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
