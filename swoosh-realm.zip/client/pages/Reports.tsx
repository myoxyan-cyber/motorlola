import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  BarChart3,
  Calendar,
  Download,
  Users,
  TrendingUp,
  TrendingDown,
  Activity,
  FileText,
  Clock,
  CheckCircle,
  XCircle,
  RefreshCw
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

interface ReportData {
  daily: DailyReport[];
  weekly: WeeklyReport[];
  monthly: MonthlyReport[];
  yearly: YearlyReport[];
  summary: ReportSummary;
}

interface DailyReport {
  date: string;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface WeeklyReport {
  week: string;
  weekNumber: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface MonthlyReport {
  month: string;
  year: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface YearlyReport {
  year: number;
  totalRecords: number;
  activeWa: number;
  inactiveWa: number;
  completedFollowUps: number;
  pendingFollowUps: number;
}

interface ReportSummary {
  totalRecords: number;
  totalActiveWa: number;
  totalInactiveWa: number;
  totalCompleted: number;
  totalPending: number;
  completionRate: number;
  activeRate: number;
}

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

export default function Reports() {
  const [reportData, setReportData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('daily');
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });

  // Fetch report data from API
  const fetchReportData = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/reports?start=${dateRange.startDate}&end=${dateRange.endDate}`);
      const result = await response.json();
      if (result.success) {
        setReportData(result.data);
      } else {
        toast.error("Gagal mengambil data laporan");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat mengambil data laporan");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReportData();
  }, [dateRange]);

  // Export report data
  const exportReport = (type: 'csv' | 'pdf', period: string) => {
    if (!reportData) return;

    let data: any[] = [];
    let filename = `laporan-${period}-${new Date().toISOString().split('T')[0]}`;

    switch (period) {
      case 'daily':
        data = reportData.daily;
        break;
      case 'weekly':
        data = reportData.weekly;
        break;
      case 'monthly':
        data = reportData.monthly;
        break;
      case 'yearly':
        data = reportData.yearly;
        break;
    }

    if (type === 'csv') {
      exportToCsv(data, filename);
    }
    
    toast.success(`Laporan ${period} berhasil diexport`);
  };

  const exportToCsv = (data: any[], filename: string) => {
    const headers = Object.keys(data[0] || {});
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(header => row[header]).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('id-ID').format(num);
  };

  const formatPercentage = (num: number) => {
    return `${num.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (!reportData) {
    return (
      <div className="p-8 text-center">
        <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-500">Tidak ada data laporan yang tersedia</p>
        <Button onClick={fetchReportData} className="mt-4">
          <RefreshCw className="h-4 w-4 mr-2" />
          Muat Ulang
        </Button>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center space-x-3">
            <BarChart3 className="h-8 w-8 text-blue-600" />
            <span>Laporan</span>
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Analisis data follow up harian, mingguan, bulanan, dan tahunan</p>
        </div>
        <Button onClick={fetchReportData} variant="outline" className="flex items-center space-x-2">
          <RefreshCw className="h-4 w-4" />
          <span>Refresh</span>
        </Button>
      </div>

      {/* Date Range Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-green-600" />
            <span>Filter Tanggal</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div>
              <Label htmlFor="start-date">Tanggal Mulai</Label>
              <Input
                id="start-date"
                type="date"
                value={dateRange.startDate}
                onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="end-date">Tanggal Akhir</Label>
              <Input
                id="end-date"
                type="date"
                value={dateRange.endDate}
                onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
              />
            </div>
            <Button onClick={fetchReportData} className="bg-green-600 hover:bg-green-700">
              <Activity className="h-4 w-4 mr-2" />
              Terapkan Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Records</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatNumber(reportData.summary.totalRecords)}</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-green-600">
              <TrendingUp className="h-4 w-4 mr-1" />
              <span className="text-sm font-medium">Total data follow up</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">WA Aktif</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatNumber(reportData.summary.totalActiveWa)}</p>
              </div>
              <div className="h-12 w-12 bg-green-100 dark:bg-green-900/50 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-green-600">
              <span className="text-sm font-medium">{formatPercentage(reportData.summary.activeRate)} dari total</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Follow Up Selesai</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatNumber(reportData.summary.totalCompleted)}</p>
              </div>
              <div className="h-12 w-12 bg-purple-100 dark:bg-purple-900/50 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-purple-600">
              <span className="text-sm font-medium">{formatPercentage(reportData.summary.completionRate)} completion rate</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatNumber(reportData.summary.totalPending)}</p>
              </div>
              <div className="h-12 w-12 bg-orange-100 dark:bg-orange-900/50 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-orange-600">
              <span className="text-sm font-medium">Menunggu follow up</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Tabs */}
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <div className="flex items-center justify-between">
          <TabsList className="grid w-full max-w-md grid-cols-4">
            <TabsTrigger value="daily">Harian</TabsTrigger>
            <TabsTrigger value="weekly">Mingguan</TabsTrigger>
            <TabsTrigger value="monthly">Bulanan</TabsTrigger>
            <TabsTrigger value="yearly">Tahunan</TabsTrigger>
          </TabsList>
          
          <div className="flex space-x-2">
            <Button
              onClick={() => exportReport('csv', activeTab)}
              variant="outline"
              size="sm"
            >
              <Download className="h-4 w-4 mr-1" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Daily Report */}
        <TabsContent value="daily">
          <div className="space-y-6">
            {/* Daily Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Trend Harian</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={reportData.daily}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickFormatter={formatDate} />
                    <YAxis />
                    <Tooltip labelFormatter={formatDate} />
                    <Legend />
                    <Line type="monotone" dataKey="totalRecords" stroke="#3B82F6" name="Total Records" />
                    <Line type="monotone" dataKey="activeWa" stroke="#10B981" name="WA Aktif" />
                    <Line type="monotone" dataKey="completedFollowUps" stroke="#8B5CF6" name="Follow Up Selesai" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Daily Table */}
            <Card>
              <CardHeader>
                <CardTitle>Data Harian Detail</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-50 dark:bg-gray-800 border-b">
                        <th className="px-4 py-3 text-left text-sm font-medium">Tanggal</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Total Records</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">WA Aktif</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">WA Tidak Aktif</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Follow Up Selesai</th>
                        <th className="px-4 py-3 text-left text-sm font-medium">Pending</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reportData.daily.map((day, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                          <td className="px-4 py-3 text-sm">{formatDate(day.date)}</td>
                          <td className="px-4 py-3 text-sm font-medium">{formatNumber(day.totalRecords)}</td>
                          <td className="px-4 py-3 text-sm text-green-600">{formatNumber(day.activeWa)}</td>
                          <td className="px-4 py-3 text-sm text-red-600">{formatNumber(day.inactiveWa)}</td>
                          <td className="px-4 py-3 text-sm text-purple-600">{formatNumber(day.completedFollowUps)}</td>
                          <td className="px-4 py-3 text-sm text-orange-600">{formatNumber(day.pendingFollowUps)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Weekly Report */}
        <TabsContent value="weekly">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Trend Mingguan</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={reportData.weekly}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="totalRecords" fill="#3B82F6" name="Total Records" />
                    <Bar dataKey="activeWa" fill="#10B981" name="WA Aktif" />
                    <Bar dataKey="completedFollowUps" fill="#8B5CF6" name="Follow Up Selesai" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Monthly Report */}
        <TabsContent value="monthly">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Trend Bulanan</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={reportData.monthly}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="totalRecords" fill="#3B82F6" name="Total Records" />
                    <Bar dataKey="activeWa" fill="#10B981" name="WA Aktif" />
                    <Bar dataKey="completedFollowUps" fill="#8B5CF6" name="Follow Up Selesai" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Yearly Report */}
        <TabsContent value="yearly">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Trend Tahunan</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={reportData.yearly}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="year" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="totalRecords" fill="#3B82F6" name="Total Records" />
                    <Bar dataKey="activeWa" fill="#10B981" name="WA Aktif" />
                    <Bar dataKey="completedFollowUps" fill="#8B5CF6" name="Follow Up Selesai" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
