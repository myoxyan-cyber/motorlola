import { RequestHandler } from "express";
import { FollowUpRecord, CreateFollowUpRequest, UpdateFollowUpRequest, BulkCreateFollowUpRequest, FollowUpResponse, DashboardStats } from "@shared/followup";
import { supabase, DatabaseRow } from "../lib/supabase";
import { z } from "zod";

// Validation schemas
const createFollowUpSchema = z.object({
  tanggal: z.string(),
  userId: z.string(),
  namaRekening: z.string(),
  noWa: z.string(),
  kataKata: z.string(),
  statusWa: z.enum(['aktif', 'tidak aktif']).optional(),
  namaCS: z.string().optional(),
  fotoBukti: z.string().optional(),
});

const updateFollowUpSchema = z.object({
  statusWa: z.enum(['aktif', 'tidak aktif']).optional(),
  namaCS: z.string().optional(),
  fotoBukti: z.string().optional(),
});

const bulkCreateSchema = z.object({
  records: z.array(createFollowUpSchema),
});

const bulkDeleteSchema = z.object({
  ids: z.array(z.string()),
});

const bulkUpdateSchema = z.object({
  ids: z.array(z.string()),
  namaCS: z.string().optional(),
  statusWa: z.enum(['aktif', 'tidak aktif']).optional(),
});

// Helper function to convert database row to FollowUpRecord
const convertToFollowUpRecord = (row: DatabaseRow): FollowUpRecord => ({
  id: row.id,
  tanggal: row.tanggal,
  userId: row.user_id,
  namaRekening: row.nama_rekening,
  noWa: row.no_wa,
  kataKata: row.kata_kata,
  statusWa: row.status_wa,
  namaCS: row.nama_cs,
  fotoBukti: row.foto_bukti,
  createdAt: row.created_at,
  updatedAt: row.updated_at,
});

// Helper function to upload file to Supabase Storage
const uploadToStorage = async (file: Buffer, fileName: string): Promise<string | null> => {
  try {
    const { data, error } = await supabase.storage
      .from('followup-photos')
      .upload(fileName, file, {
        contentType: 'image/jpeg',
        upsert: true
      });

    if (error) {
      console.error('Storage upload error:', error);
      return null;
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from('followup-photos')
      .getPublicUrl(fileName);

    return urlData.publicUrl;
  } catch (error) {
    console.error('Upload error:', error);
    return null;
  }
};

// Helper function to delete file from Supabase Storage
const deleteFromStorage = async (fileName: string): Promise<boolean> => {
  try {
    const { error } = await supabase.storage
      .from('followup-photos')
      .remove([fileName]);

    if (error) {
      console.error('Storage delete error:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Delete error:', error);
    return false;
  }
};

// Get all follow-up records
export const getAllFollowUps: RequestHandler = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('follow_up_records')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error fetching records: ' + error.message
      };
      return res.status(500).json(response);
    }

    const records = data.map(convertToFollowUpRecord);
    const response: FollowUpResponse = {
      success: true,
      data: records
    };
    res.json(response);
  } catch (error) {
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Get single follow-up record
export const getFollowUp: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    
    const { data, error } = await supabase
      .from('follow_up_records')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: error.code === 'PGRST116' ? 'Record not found' : 'Error fetching record: ' + error.message
      };
      return res.status(error.code === 'PGRST116' ? 404 : 500).json(response);
    }

    const record = convertToFollowUpRecord(data);
    const response: FollowUpResponse = {
      success: true,
      data: record
    };
    res.json(response);
  } catch (error) {
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Create single follow-up record
export const createFollowUp: RequestHandler = async (req, res) => {
  try {
    const validatedData = createFollowUpSchema.parse(req.body);
    
    const { data, error } = await supabase
      .from('follow_up_records')
      .insert({
        tanggal: validatedData.tanggal,
        user_id: validatedData.userId,
        nama_rekening: validatedData.namaRekening,
        no_wa: validatedData.noWa,
        kata_kata: validatedData.kataKata,
        status_wa: validatedData.statusWa || 'tidak aktif',
        nama_cs: validatedData.namaCS || '',
        foto_bukti: validatedData.fotoBukti || null,
      })
      .select()
      .single();

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error creating record: ' + error.message
      };
      return res.status(500).json(response);
    }

    const record = convertToFollowUpRecord(data);
    const response: FollowUpResponse = {
      success: true,
      data: record,
      message: 'Record created successfully'
    };
    res.status(201).json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      };
      return res.status(400).json(response);
    }
    
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Bulk create follow-up records
export const bulkCreateFollowUps: RequestHandler = async (req, res) => {
  try {
    const validatedData = bulkCreateSchema.parse(req.body);
    
    const insertData = validatedData.records.map(record => ({
      tanggal: record.tanggal,
      user_id: record.userId,
      nama_rekening: record.namaRekening,
      no_wa: record.noWa,
      kata_kata: record.kataKata,
      status_wa: record.statusWa || 'tidak aktif',
      nama_cs: record.namaCS || '',
      foto_bukti: record.fotoBukti || null,
    }));

    const { data, error } = await supabase
      .from('follow_up_records')
      .insert(insertData)
      .select();

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error creating records: ' + error.message
      };
      return res.status(500).json(response);
    }

    const records = data.map(convertToFollowUpRecord);
    const response: FollowUpResponse = {
      success: true,
      data: records,
      message: `${records.length} records created successfully`
    };
    res.status(201).json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      };
      return res.status(400).json(response);
    }
    
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Update follow-up record
export const updateFollowUp: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const validatedData = updateFollowUpSchema.parse(req.body);
    
    const updateData: any = {};
    if (validatedData.statusWa) updateData.status_wa = validatedData.statusWa;
    if (validatedData.namaCS !== undefined) updateData.nama_cs = validatedData.namaCS;
    if (validatedData.fotoBukti !== undefined) updateData.foto_bukti = validatedData.fotoBukti;

    const { data, error } = await supabase
      .from('follow_up_records')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: error.code === 'PGRST116' ? 'Record not found' : 'Error updating record: ' + error.message
      };
      return res.status(error.code === 'PGRST116' ? 404 : 500).json(response);
    }

    const record = convertToFollowUpRecord(data);
    const response: FollowUpResponse = {
      success: true,
      data: record,
      message: 'Record updated successfully'
    };
    res.json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      };
      return res.status(400).json(response);
    }
    
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Delete follow-up record
export const deleteFollowUp: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    
    // First get the record to check if it has a photo
    const { data: record, error: fetchError } = await supabase
      .from('follow_up_records')
      .select('foto_bukti')
      .eq('id', id)
      .single();

    if (fetchError && fetchError.code !== 'PGRST116') {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error fetching record: ' + fetchError.message
      };
      return res.status(500).json(response);
    }

    // Delete the photo from storage if it exists
    if (record?.foto_bukti) {
      const fileName = record.foto_bukti.split('/').pop();
      if (fileName) {
        await deleteFromStorage(fileName);
      }
    }

    // Delete the record
    const { error } = await supabase
      .from('follow_up_records')
      .delete()
      .eq('id', id);

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error deleting record: ' + error.message
      };
      return res.status(500).json(response);
    }

    const response: FollowUpResponse = {
      success: true,
      message: 'Record deleted successfully'
    };
    res.json(response);
  } catch (error) {
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Get dashboard statistics
export const getDashboardStats: RequestHandler = async (req, res) => {
  try {
    // Get total count
    const { count: totalRecords, error: totalError } = await supabase
      .from('follow_up_records')
      .select('*', { count: 'exact', head: true });

    if (totalError) {
      throw totalError;
    }

    // Get active WA count
    const { count: activeWa, error: activeError } = await supabase
      .from('follow_up_records')
      .select('*', { count: 'exact', head: true })
      .eq('status_wa', 'aktif');

    if (activeError) {
      throw activeError;
    }

    // Get inactive WA count
    const { count: inactiveWa, error: inactiveError } = await supabase
      .from('follow_up_records')
      .select('*', { count: 'exact', head: true })
      .eq('status_wa', 'tidak aktif');

    if (inactiveError) {
      throw inactiveError;
    }

    // Get pending follow up count (empty or null nama_cs)
    const { count: pendingFollowUp, error: pendingError } = await supabase
      .from('follow_up_records')
      .select('*', { count: 'exact', head: true })
      .or('nama_cs.is.null,nama_cs.eq.');

    if (pendingError) {
      throw pendingError;
    }

    // Get completed today count
    const today = new Date().toISOString().split('T')[0];
    const { count: completedToday, error: completedError } = await supabase
      .from('follow_up_records')
      .select('*', { count: 'exact', head: true })
      .gte('updated_at', today)
      .not('nama_cs', 'is', null)
      .not('nama_cs', 'eq', '');

    if (completedError) {
      throw completedError;
    }

    const stats: DashboardStats = {
      totalRecords: totalRecords || 0,
      activeWa: activeWa || 0,
      inactiveWa: inactiveWa || 0,
      pendingFollowUp: pendingFollowUp || 0,
      completedToday: completedToday || 0,
    };

    res.json(stats);
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({
      totalRecords: 0,
      activeWa: 0,
      inactiveWa: 0,
      pendingFollowUp: 0,
      completedToday: 0,
    });
  }
};

// Bulk delete follow-up records
export const bulkDeleteFollowUps: RequestHandler = async (req, res) => {
  try {
    const validatedData = bulkDeleteSchema.parse(req.body);

    if (validatedData.ids.length === 0) {
      const response: FollowUpResponse = {
        success: false,
        message: 'No IDs provided for deletion'
      };
      return res.status(400).json(response);
    }

    // First get all records to check for photos that need to be deleted
    const { data: records, error: fetchError } = await supabase
      .from('follow_up_records')
      .select('id, foto_bukti')
      .in('id', validatedData.ids);

    if (fetchError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error fetching records: ' + fetchError.message
      };
      return res.status(500).json(response);
    }

    // Delete photos from storage
    const deletePhotoPromises = records
      .filter(record => record.foto_bukti)
      .map(record => {
        const fileName = record.foto_bukti!.split('/').pop();
        return fileName ? deleteFromStorage(fileName) : Promise.resolve(false);
      });

    await Promise.all(deletePhotoPromises);

    // Delete the records
    const { error } = await supabase
      .from('follow_up_records')
      .delete()
      .in('id', validatedData.ids);

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error deleting records: ' + error.message
      };
      return res.status(500).json(response);
    }

    const response: FollowUpResponse = {
      success: true,
      message: `${validatedData.ids.length} records deleted successfully`
    };
    res.json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      };
      return res.status(400).json(response);
    }

    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Bulk update follow-up records
export const bulkUpdateFollowUps: RequestHandler = async (req, res) => {
  try {
    const validatedData = bulkUpdateSchema.parse(req.body);

    if (validatedData.ids.length === 0) {
      const response: FollowUpResponse = {
        success: false,
        message: 'No IDs provided for update'
      };
      return res.status(400).json(response);
    }

    if (!validatedData.namaCS && !validatedData.statusWa) {
      const response: FollowUpResponse = {
        success: false,
        message: 'No update data provided'
      };
      return res.status(400).json(response);
    }

    const updateData: any = {};
    if (validatedData.namaCS !== undefined) updateData.nama_cs = validatedData.namaCS;
    if (validatedData.statusWa) updateData.status_wa = validatedData.statusWa;

    const { data, error } = await supabase
      .from('follow_up_records')
      .update(updateData)
      .in('id', validatedData.ids)
      .select();

    if (error) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error updating records: ' + error.message
      };
      return res.status(500).json(response);
    }

    const records = data.map(convertToFollowUpRecord);
    const response: FollowUpResponse = {
      success: true,
      data: records,
      message: `${validatedData.ids.length} records updated successfully`
    };
    res.json(response);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      };
      return res.status(400).json(response);
    }

    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};

// Upload photo using Supabase Storage
export const uploadPhoto: RequestHandler = async (req, res) => {
  try {
    const { recordId, photoData } = req.body;
    
    if (!photoData) {
      // If photoData is null, we're deleting the photo
      const { data, error } = await supabase
        .from('follow_up_records')
        .update({ foto_bukti: null })
        .eq('id', recordId)
        .select()
        .single();

      if (error) {
        const response: FollowUpResponse = {
          success: false,
          message: error.code === 'PGRST116' ? 'Record not found' : 'Error removing photo: ' + error.message
        };
        return res.status(error.code === 'PGRST116' ? 404 : 500).json(response);
      }

      const record = convertToFollowUpRecord(data);
      const response: FollowUpResponse = {
        success: true,
        data: record,
        message: 'Photo removed successfully'
      };
      return res.json(response);
    }

    // First get the existing record to check for old photo
    const { data: existingRecord, error: fetchError } = await supabase
      .from('follow_up_records')
      .select('foto_bukti')
      .eq('id', recordId)
      .single();

    if (fetchError && fetchError.code !== 'PGRST116') {
      const response: FollowUpResponse = {
        success: false,
        message: 'Error fetching record: ' + fetchError.message
      };
      return res.status(500).json(response);
    }

    // Delete old photo if it exists
    if (existingRecord?.foto_bukti) {
      const oldFileName = existingRecord.foto_bukti.split('/').pop();
      if (oldFileName) {
        await deleteFromStorage(oldFileName);
      }
    }

    // Convert base64 to buffer
    const base64Data = photoData.replace(/^data:image\/[a-z]+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    
    // Generate unique filename
    const timestamp = Date.now();
    const fileName = `${recordId}-${timestamp}.jpg`;
    
    // Upload to Supabase Storage
    const publicUrl = await uploadToStorage(buffer, fileName);
    
    if (!publicUrl) {
      const response: FollowUpResponse = {
        success: false,
        message: 'Failed to upload photo to storage'
      };
      return res.status(500).json(response);
    }

    // Update database with photo URL
    const { data, error } = await supabase
      .from('follow_up_records')
      .update({ foto_bukti: publicUrl })
      .eq('id', recordId)
      .select()
      .single();

    if (error) {
      // Clean up uploaded file if database update fails
      await deleteFromStorage(fileName);
      
      const response: FollowUpResponse = {
        success: false,
        message: error.code === 'PGRST116' ? 'Record not found' : 'Error updating record: ' + error.message
      };
      return res.status(error.code === 'PGRST116' ? 404 : 500).json(response);
    }

    const record = convertToFollowUpRecord(data);
    const response: FollowUpResponse = {
      success: true,
      data: record,
      message: 'Photo uploaded successfully'
    };
    res.json(response);
  } catch (error) {
    console.error('Upload error:', error);
    const response: FollowUpResponse = {
      success: false,
      message: 'Server error: ' + (error as Error).message
    };
    res.status(500).json(response);
  }
};
