import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import {
  getAllFollowUps,
  getFollowUp,
  createFollowUp,
  bulkCreateFollowUps,
  updateFollowUp,
  deleteFollowUp,
  bulkDeleteFollowUps,
  bulkUpdateFollowUps,
  getDashboardStats,
  uploadPhoto
} from "./routes/followup";
import { login, verifySession } from "./routes/auth";
import {
  getAllUsers,
  getUser,
  createUser,
  updateUser,
  deleteUser
} from "./routes/users";
import { getReports, getCSPerformance } from "./routes/reports";
import { debugInfo, createAdmin } from "./routes/debug";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());

  // Handle body parsing - check if Vite already parsed it
  app.use((req, res, next) => {
    // If body is already parsed by Vite, use it
    if (req.body !== undefined) {
      return next();
    }

    // Otherwise, use Express body parser
    express.json({ limit: '50mb' })(req, res, next);
  });

  app.use((req, res, next) => {
    // Skip if already has parsed body or if not a form submission
    if (req.body !== undefined || !req.headers['content-type']?.includes('application/x-www-form-urlencoded')) {
      return next();
    }

    express.urlencoded({ extended: true, limit: '50mb' })(req, res, next);
  });

  // Example API routes
  app.get("/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/demo", handleDemo);

  // Authentication routes
  app.post("/auth/login", login);
  app.get("/auth/verify", verifySession);

  // User management routes
  app.get("/users", getAllUsers);
  app.post("/users", createUser);
  app.get("/users/:id", getUser);
  app.put("/users/:id", updateUser);
  app.delete("/users/:id", deleteUser);

  // Reports routes
  app.get("/reports", getReports);
  app.get("/reports/cs-performance", getCSPerformance);

  // Debug routes (temporary)
  app.get("/debug", debugInfo);
  app.post("/debug/create-admin", createAdmin);

  // Follow-up management routes
  app.get("/followups", getAllFollowUps);
  app.post("/followups", createFollowUp);
  app.post("/followups/bulk", bulkCreateFollowUps);
  app.post("/followups/upload-photo", uploadPhoto);
  app.get("/dashboard/stats", getDashboardStats);

  // Bulk operations (must come before :id routes)
  app.delete("/followups/bulk-delete", bulkDeleteFollowUps);
  app.put("/followups/bulk-update", bulkUpdateFollowUps);

  // Single record operations (must come after bulk routes)
  app.get("/followups/:id", getFollowUp);
  app.put("/followups/:id", updateFollowUp);
  app.delete("/followups/:id", deleteFollowUp);

  return app;
}
