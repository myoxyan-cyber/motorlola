import { RequestHandler } from "express";
import { supabase } from "../lib/supabase";
import bcrypt from "bcrypt";

// Debug endpoint to check database connection and users
export const debugInfo: RequestHandler = async (req, res) => {
  try {
    // Check Supabase connection
    const { data: users, error } = await supabase
      .from('users')
      .select('id, username, name, role, created_at');

    if (error) {
      return res.json({
        success: false,
        message: 'Database connection error',
        error: error.message,
        supabase_url: process.env.SUPABASE_URL,
        env_check: {
          SUPABASE_URL: !!process.env.SUPABASE_URL,
          SUPABASE_ANON_KEY: !!process.env.SUPABASE_ANON_KEY,
          SUPABASE_SERVICE_ROLE_KEY: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
        }
      });
    }

    res.json({
      success: true,
      message: 'Database connection successful',
      users_count: users?.length || 0,
      users: users,
      env_check: {
        SUPABASE_URL: !!process.env.SUPABASE_URL,
        SUPABASE_ANON_KEY: !!process.env.SUPABASE_ANON_KEY,
        SUPABASE_SERVICE_ROLE_KEY: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
      }
    });
  } catch (error) {
    console.error('Debug error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: (error as Error).message
    });
  }
};

// Create admin user endpoint (only for setup)
export const createAdmin: RequestHandler = async (req, res) => {
  try {
    const { username = 'admin', password = 'admin123', name = 'Administrator' } = req.body;

    // Check if admin already exists
    const { data: existing } = await supabase
      .from('users')
      .select('username')
      .eq('username', username)
      .single();

    if (existing) {
      return res.json({
        success: false,
        message: 'Admin user already exists'
      });
    }

    // Create admin user
    const passwordHash = await bcrypt.hash(password, 10);
    
    const { data: newUser, error } = await supabase
      .from('users')
      .insert({
        username,
        name,
        password_hash: passwordHash,
        role: 'admin'
      })
      .select('id, username, name, role')
      .single();

    if (error) {
      return res.status(500).json({
        success: false,
        message: 'Error creating admin',
        error: error.message
      });
    }

    res.json({
      success: true,
      message: 'Admin user created successfully',
      user: newUser,
      credentials: {
        username,
        password
      }
    });
  } catch (error) {
    console.error('Create admin error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: (error as Error).message
    });
  }
};
