import Dashboard from "./Dashboard";

export default function Index() {
  return <Dashboard />;
}
