import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import {
  Users,
  Plus,
  Edit2,
  Trash2,
  Save,
  X,
  Search,
  RefreshCw,
  UserPlus,
  Shield,
  User
} from "lucide-react";

interface CSUser {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'cs';
  createdAt: string;
  updatedAt: string;
}

interface EditingUser {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'cs';
  password?: string;
}

export default function CSManagement() {
  const [users, setUsers] = useState<CSUser[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<CSUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [editingUsers, setEditingUsers] = useState<Map<string, EditingUser>>(new Map());
  const [showAddForm, setShowAddForm] = useState(false);
  const [newUser, setNewUser] = useState({
    username: "",
    name: "",
    role: "cs" as 'admin' | 'cs',
    password: "",
  });

  // Fetch users from API
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/users');
      const result = await response.json();
      if (result.success) {
        setUsers(result.data);
        setFilteredUsers(result.data);
      } else {
        toast.error("Gagal mengambil data pengguna");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat mengambil data pengguna");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Filter users based on search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(user =>
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  }, [searchTerm, users]);

  // Start editing a user
  const startEditing = (user: CSUser) => {
    const newEditingUsers = new Map(editingUsers);
    newEditingUsers.set(user.id, {
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
    });
    setEditingUsers(newEditingUsers);
  };

  // Cancel editing
  const cancelEditing = (id: string) => {
    const newEditingUsers = new Map(editingUsers);
    newEditingUsers.delete(id);
    setEditingUsers(newEditingUsers);
  };

  // Update editing user data
  const updateEditingUser = (id: string, field: keyof EditingUser, value: string) => {
    const newEditingUsers = new Map(editingUsers);
    const currentUser = newEditingUsers.get(id);
    if (currentUser) {
      newEditingUsers.set(id, { ...currentUser, [field]: value });
      setEditingUsers(newEditingUsers);
    }
  };

  // Save user changes
  const saveUserChanges = async (id: string) => {
    const editingUser = editingUsers.get(id);
    if (!editingUser) return;

    try {
      const payload: any = {
        username: editingUser.username,
        name: editingUser.name,
        role: editingUser.role,
      };
      
      if (editingUser.password) {
        payload.password = editingUser.password;
      }

      const response = await fetch(`/api/users/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();
      if (result.success) {
        await fetchUsers();
        cancelEditing(id);
        toast.success("Data pengguna berhasil disimpan");
      } else {
        toast.error(result.message || "Gagal menyimpan data pengguna");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menyimpan data pengguna");
    }
  };

  // Delete user
  const deleteUser = async (id: string, username: string) => {
    if (!confirm(`Apakah Anda yakin ingin menghapus pengguna "${username}"?`)) return;

    try {
      const response = await fetch(`/api/users/${id}`, {
        method: 'DELETE',
      });

      const result = await response.json();
      if (result.success) {
        await fetchUsers();
        toast.success("Pengguna berhasil dihapus");
      } else {
        toast.error(result.message || "Gagal menghapus pengguna");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menghapus pengguna");
    }
  };

  // Add new user
  const addNewUser = async () => {
    if (!newUser.username || !newUser.name || !newUser.password) {
      toast.error("Semua field harus diisi");
      return;
    }

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });

      const result = await response.json();
      if (result.success) {
        await fetchUsers();
        setShowAddForm(false);
        setNewUser({ username: "", name: "", role: "cs", password: "" });
        toast.success("Pengguna berhasil ditambahkan");
      } else {
        toast.error(result.message || "Gagal menambahkan pengguna");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menambahkan pengguna");
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
            <Users className="h-8 w-8 text-blue-600" />
            <span>CS Management</span>
          </h1>
          <p className="text-gray-600 mt-2">Kelola akun CS dan admin</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            {filteredUsers.length} pengguna
          </Badge>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Cari username atau nama..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button onClick={fetchUsers} variant="outline" className="flex items-center space-x-2">
            <RefreshCw className="h-4 w-4" />
            <span>Refresh</span>
          </Button>
        </div>
        
        <Button 
          onClick={() => setShowAddForm(true)} 
          className="bg-blue-600 hover:bg-blue-700 flex items-center space-x-2"
        >
          <UserPlus className="h-4 w-4" />
          <span>Tambah Pengguna</span>
        </Button>
      </div>

      {/* Add User Form */}
      {showAddForm && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Plus className="h-5 w-5 text-blue-600" />
              <span>Tambah Pengguna Baru</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="new-username">Username</Label>
                <Input
                  id="new-username"
                  placeholder="Username"
                  value={newUser.username}
                  onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="new-name">Nama Lengkap</Label>
                <Input
                  id="new-name"
                  placeholder="Nama lengkap"
                  value={newUser.name}
                  onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="new-role">Role</Label>
                <Select
                  value={newUser.role}
                  onValueChange={(value: 'admin' | 'cs') => setNewUser(prev => ({ ...prev, role: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cs">CS</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="new-password">Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="Password"
                  value={newUser.password}
                  onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>
            </div>
            <div className="flex gap-3 mt-4">
              <Button onClick={addNewUser} className="bg-blue-600 hover:bg-blue-700">
                <Save className="h-4 w-4 mr-2" />
                Simpan
              </Button>
              <Button 
                onClick={() => {
                  setShowAddForm(false);
                  setNewUser({ username: "", name: "", role: "cs", password: "" });
                }} 
                variant="outline"
              >
                <X className="h-4 w-4 mr-2" />
                Batal
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b">
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Username</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Nama Lengkap</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Role</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Password</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Dibuat</th>
                  <th className="px-4 py-3 text-center text-sm font-medium text-gray-900">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => {
                  const isEditing = editingUsers.has(user.id);
                  const editingUser = editingUsers.get(user.id);

                  return (
                    <tr key={user.id} className="border-b hover:bg-gray-50">
                      {/* Username */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Input
                            value={editingUser?.username || user.username}
                            onChange={(e) => updateEditingUser(user.id, 'username', e.target.value)}
                            className="w-32"
                          />
                        ) : (
                          <span className="text-sm text-gray-900 font-medium">{user.username}</span>
                        )}
                      </td>

                      {/* Name */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Input
                            value={editingUser?.name || user.name}
                            onChange={(e) => updateEditingUser(user.id, 'name', e.target.value)}
                            className="w-48"
                          />
                        ) : (
                          <span className="text-sm text-gray-900">{user.name}</span>
                        )}
                      </td>

                      {/* Role */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Select
                            value={editingUser?.role || user.role}
                            onValueChange={(value: 'admin' | 'cs') => 
                              updateEditingUser(user.id, 'role', value)
                            }
                          >
                            <SelectTrigger className="w-24">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="cs">CS</SelectItem>
                              <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Badge 
                            variant={user.role === 'admin' ? 'default' : 'secondary'}
                            className={user.role === 'admin' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}
                          >
                            {user.role === 'admin' ? (
                              <>
                                <Shield className="h-3 w-3 mr-1" />
                                Admin
                              </>
                            ) : (
                              <>
                                <User className="h-3 w-3 mr-1" />
                                CS
                              </>
                            )}
                          </Badge>
                        )}
                      </td>

                      {/* Password */}
                      <td className="px-4 py-3">
                        {isEditing ? (
                          <Input
                            type="password"
                            placeholder="Password baru (opsional)"
                            value={editingUser?.password || ""}
                            onChange={(e) => updateEditingUser(user.id, 'password', e.target.value)}
                            className="w-48"
                          />
                        ) : (
                          <span className="text-xs text-gray-400">••••••••</span>
                        )}
                      </td>

                      {/* Created Date */}
                      <td className="px-4 py-3">
                        <span className="text-sm text-gray-500">
                          {new Date(user.createdAt).toLocaleDateString('id-ID')}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center space-x-2">
                          {isEditing ? (
                            <>
                              <Button
                                size="sm"
                                onClick={() => saveUserChanges(user.id)}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <Save className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => cancelEditing(user.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => startEditing(user)}
                              >
                                <Edit2 className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteUser(user.id, user.username)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredUsers.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Tidak ada pengguna yang ditemukan</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
