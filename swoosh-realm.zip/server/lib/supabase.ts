import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface DatabaseRow {
  id: string;
  tanggal: string;
  user_id: string;
  nama_rekening: string;
  no_wa: string;
  kata_kata: string;
  status_wa: 'aktif' | 'tidak aktif';
  nama_cs: string;
  foto_bukti?: string;
  created_at: string;
  updated_at: string;
}

export type Database = {
  public: {
    Tables: {
      follow_up_records: {
        Row: DatabaseRow;
        Insert: Omit<DatabaseRow, 'id' | 'created_at' | 'updated_at'> & {
          id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: Partial<Omit<DatabaseRow, 'id' | 'created_at' | 'updated_at'>>;
      };
    };
  };
};
