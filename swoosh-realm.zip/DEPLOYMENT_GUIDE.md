# 🚀 Panduan Deploy ke Niagahoster

## Prerequisites
Pastikan Anda sudah punya:
- **VPS atau Cloud Hosting** Niagahoster (tidak bisa pakai shared hosting)
- **Domain** yang sudah dipointing ke VPS
- **Access SSH** ke VPS

## 📦 Langkah 1: Build Production

Jalankan commands ini di local computer:

```bash
# Install dependencies
npm install

# Build untuk production
npm run build
```

## 🌐 Langkah 2: Setup di VPS Niagahoster

### A. Connect ke VPS via SSH
```bash
ssh root@your-vps-ip
```

### B. Install Node.js dan PM2
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 untuk process management
sudo npm install -g pm2

# Install Nginx untuk reverse proxy
sudo apt install nginx -y
```

### C. Upload Files ke VPS
Bisa pakai FileZilla atau SCP:

```bash
# Buat folder project
mkdir /var/www/followup-manager
cd /var/www/followup-manager

# Upload semua files project ke folder ini
```

### D. Install Dependencies di VPS
```bash
cd /var/www/followup-manager
npm install --production
```

## ⚙️ Langkah 3: Environment Variables

Buat file `.env` di VPS:

```bash
nano .env
```

Isi dengan:
```env
NODE_ENV=production
PORT=3000

# Supabase Config
SUPABASE_URL=https://uzdbsesnrckllmfgqalt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV6ZGJzZXNucmNrbGxtZmdxYWx0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY5NDg3MTMsImV4cCI6MjA3MjUyNDcxM30.x3RbgGy-ryZfWvZO_LAVbK7moiWinXTwDIcTd2B4-kA
```

## 🚀 Langkah 4: Start Application

```bash
# Start dengan PM2
pm2 start dist/server/node-build.mjs --name "followup-manager"

# Set PM2 auto start pada boot
pm2 startup
pm2 save
```

## 🌐 Langkah 5: Setup Nginx

Buat config Nginx:

```bash
sudo nano /etc/nginx/sites-available/followup-manager
```

Isi dengan (ganti `your-domain.com`):

```nginx
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    # Serve static files
    location / {
        root /var/www/followup-manager/dist/spa;
        try_files $uri $uri/ /index.html;
    }

    # API routes
    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/followup-manager /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 🔒 Langkah 6: SSL Certificate (Opsional)

Install Certbot untuk SSL gratis:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com -d www.your-domain.com
```

## ✅ Verifikasi

1. Cek aplikasi running: `pm2 status`
2. Cek logs: `pm2 logs followup-manager`
3. Akses domain Anda di browser

## 🛠️ Maintenance Commands

```bash
# Restart aplikasi
pm2 restart followup-manager

# View logs
pm2 logs followup-manager

# Stop aplikasi
pm2 stop followup-manager

# Delete dari PM2
pm2 delete followup-manager
```

---

## 📞 Support

Jika ada kendala, cek:
1. **PM2 Status**: `pm2 status`
2. **Nginx Status**: `sudo systemctl status nginx`
3. **Application Logs**: `pm2 logs followup-manager`
4. **Nginx Logs**: `sudo tail -f /var/log/nginx/error.log`
