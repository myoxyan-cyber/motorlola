import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Upload,
  Download,
  FileText,
  CheckCircle,
  AlertCircle,
  Plus,
  Trash2,
  Save,
  FileSpreadsheet,
  TableIcon
} from "lucide-react";
import { CreateFollowUpRequest, BulkCreateFollowUpRequest } from "@shared/followup";
import * as XLSX from 'xlsx';

interface DataRow {
  id: string;
  tanggal: string;
  userId: string;
  namaRekening: string;
  noWa: string;
  kataKata: string;
}

export default function AddData() {
  // Initialize with 10 empty rows to match the spreadsheet format
  const initializeEmptyRows = () => {
    const rows: DataRow[] = [];
    for (let i = 1; i <= 10; i++) {
      rows.push({
        id: `row-${i}`,
        tanggal: new Date().toISOString().split('T')[0],
        userId: "",
        namaRekening: "",
        noWa: "",
        kataKata: ""
      });
    }
    return rows;
  };

  const [bulkData, setBulkData] = useState<DataRow[]>(initializeEmptyRows());
  const [csvInput, setCsvInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showCsvInput, setShowCsvInput] = useState(false);
  const [isProcessingExcel, setIsProcessingExcel] = useState(false);

  // Add new empty rows
  const addNewRow = () => {
    const newRows: DataRow[] = [];
    for (let i = 1; i <= 5; i++) {
      newRows.push({
        id: `${Date.now()}-${i}`,
        tanggal: new Date().toISOString().split('T')[0],
        userId: "",
        namaRekening: "",
        noWa: "",
        kataKata: ""
      });
    }
    setBulkData([...bulkData, ...newRows]);
  };

  // Remove a row
  const removeRow = (id: string) => {
    setBulkData(bulkData.filter(row => row.id !== id));
  };

  // Update a specific row
  const updateRow = (id: string, field: keyof DataRow, value: string) => {
    setBulkData(bulkData.map(row => 
      row.id === id ? { ...row, [field]: value } : row
    ));
  };

  // Handle Excel file upload
  const handleExcelUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsProcessingExcel(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });

        // Get the first worksheet
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];

        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

        // Skip header row and process data
        const rows = jsonData.slice(1) as any[];

        if (rows.length === 0) {
          toast.error("File Excel tidak memiliki data");
          setIsProcessingExcel(false);
          return;
        }

        const newRows: DataRow[] = rows
          .filter(row => row && row.length > 0 && row.some((cell: any) => cell)) // Filter empty rows
          .map((row: any[], index: number) => ({
            id: `excel-${Date.now()}-${index}`,
            tanggal: row[0] ? formatExcelDate(row[0]) : new Date().toISOString().split('T')[0],
            userId: row[1]?.toString() || "",
            namaRekening: row[2]?.toString() || "",
            noWa: row[3]?.toString() || "",
            kataKata: row[4]?.toString() || ""
          }));

        if (newRows.length === 0) {
          toast.error("Tidak ada data valid dalam file Excel");
          setIsProcessingExcel(false);
          return;
        }

        // Find first empty row to start inserting
        const firstEmptyIndex = bulkData.findIndex(row =>
          !row.userId && !row.namaRekening && !row.noWa && !row.kataKata
        );

        if (firstEmptyIndex !== -1) {
          const updatedData = [...bulkData];
          newRows.forEach((newRow, index) => {
            const targetIndex = firstEmptyIndex + index;
            if (targetIndex < updatedData.length) {
              updatedData[targetIndex] = newRow;
            } else {
              updatedData.push(newRow);
            }
          });
          setBulkData(updatedData);
        } else {
          setBulkData([...bulkData, ...newRows]);
        }

        toast.success(`${newRows.length} data berhasil diimport dari Excel`);
      } catch (error) {
        console.error('Error parsing Excel file:', error);
        toast.error("Gagal membaca file Excel. Pastikan format file benar");
      } finally {
        setIsProcessingExcel(false);
        // Reset input
        event.target.value = '';
      }
    };

    reader.readAsBinaryString(file);
  };

  // Format Excel date to YYYY-MM-DD
  const formatExcelDate = (excelDate: any): string => {
    if (typeof excelDate === 'string') {
      // If it's already a string, try to parse it
      const date = new Date(excelDate);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    } else if (typeof excelDate === 'number') {
      // Excel date serial number
      const date = new Date((excelDate - 25569) * 86400 * 1000);
      return date.toISOString().split('T')[0];
    }
    return new Date().toISOString().split('T')[0];
  };

  // Parse CSV input
  const parseCsvInput = () => {
    try {
      const lines = csvInput.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim());

      if (headers.length < 5) {
        toast.error("CSV harus memiliki minimal 5 kolom: Tanggal, User ID, Nama Rekening, No WA, Kata Kata");
        return;
      }

      const newRows: DataRow[] = lines.slice(1).map((line, index) => {
        const values = line.split(',').map(v => v.trim());
        return {
          id: `csv-${Date.now()}-${index}`,
          tanggal: values[0] || new Date().toISOString().split('T')[0],
          userId: values[1] || "",
          namaRekening: values[2] || "",
          noWa: values[3] || "",
          kataKata: values[4] || ""
        };
      });

      // Find first empty row to start inserting
      const firstEmptyIndex = bulkData.findIndex(row =>
        !row.userId && !row.namaRekening && !row.noWa && !row.kataKata
      );

      if (firstEmptyIndex !== -1) {
        const updatedData = [...bulkData];
        newRows.forEach((newRow, index) => {
          const targetIndex = firstEmptyIndex + index;
          if (targetIndex < updatedData.length) {
            updatedData[targetIndex] = newRow;
          } else {
            updatedData.push(newRow);
          }
        });
        setBulkData(updatedData);
      } else {
        setBulkData([...bulkData, ...newRows]);
      }
      setCsvInput("");
      setShowCsvInput(false);
      toast.success(`${newRows.length} baris data berhasil ditambahkan`);
    } catch (error) {
      toast.error("Format CSV tidak valid");
    }
  };

  // Submit bulk data
  const submitBulkData = async () => {
    // Filter out empty rows (rows where all fields are empty or only tanggal is filled)
    const filledRows = bulkData.filter(row =>
      row.userId && row.namaRekening && row.noWa && row.kataKata
    );

    if (filledRows.length === 0) {
      toast.error("Tidak ada data untuk disimpan");
      return;
    }

    // Validate required fields for filled rows
    const invalidRows = filledRows.filter(row =>
      !row.tanggal || !row.userId || !row.namaRekening || !row.noWa || !row.kataKata
    );

    if (invalidRows.length > 0) {
      toast.error(`${invalidRows.length} baris memiliki data yang tidak lengkap`);
      return;
    }

    setIsLoading(true);
    try {
      const request: BulkCreateFollowUpRequest = {
        records: filledRows.map(row => ({
          tanggal: row.tanggal,
          userId: row.userId,
          namaRekening: row.namaRekening,
          noWa: row.noWa,
          kataKata: row.kataKata
        }))
      };

      const response = await fetch('/api/followups/bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      const result = await response.json();

      if (result.success) {
        toast.success(`${filledRows.length} data berhasil disimpan`);
        // Reset to empty rows after successful save
        setBulkData(initializeEmptyRows());
      } else {
        toast.error(result.message || "Gagal menyimpan data");
      }
    } catch (error) {
      toast.error("Terjadi kesalahan saat menyimpan data");
    } finally {
      setIsLoading(false);
    }
  };

  // Download CSV template
  const downloadTemplate = () => {
    const csvContent = "Tanggal,User ID,Nama Rekening,No WA,Kata Kata\n2024-01-01,USER001,John Doe,08123456789,Halo selamat pagi\n2024-01-01,USER002,Jane Smith,08234567890,Selamat siang";
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'template-data-followup.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  // Download Excel template
  const downloadExcelTemplate = () => {
    const data = [
      ['Tanggal', 'User ID', 'Nama Rekening', 'No WA', 'Kata Kata'],
      ['2024-01-01', 'USER001', 'John Doe', '08123456789', 'Halo selamat pagi'],
      ['2024-01-01', 'USER002', 'Jane Smith', '08234567890', 'Selamat siang'],
      ['2024-01-01', 'USER003', 'Ahmad Rahman', '08345678901', 'Terima kasih']
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Follow Up');

    // Set column widths
    worksheet['!cols'] = [
      { width: 12 }, // Tanggal
      { width: 15 }, // User ID
      { width: 20 }, // Nama Rekening
      { width: 15 }, // No WA
      { width: 25 }  // Kata Kata
    ];

    XLSX.writeFile(workbook, 'template-data-followup.xlsx');
  };

  return (
    <div className="p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tambah Data</h1>
          <p className="text-gray-600 mt-2">Input data pelanggan secara massal</p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            {bulkData.filter(row => row.userId || row.namaRekening || row.noWa || row.kataKata).length} baris terisi
          </Badge>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <Button onClick={addNewRow} variant="outline" className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Tambah 5 Baris</span>
        </Button>
        
        <Button
          onClick={() => setShowCsvInput(!showCsvInput)}
          variant="outline"
          className="flex items-center space-x-2"
        >
          <FileText className="h-4 w-4" />
          <span>Import CSV</span>
        </Button>

        <Button
          onClick={() => document.getElementById('excel-upload')?.click()}
          disabled={isProcessingExcel}
          variant="outline"
          className="flex items-center space-x-2 bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
        >
          <FileSpreadsheet className="h-4 w-4" />
          <span>{isProcessingExcel ? 'Processing...' : 'Import Excel'}</span>
        </Button>
        <input
          id="excel-upload"
          type="file"
          accept=".xlsx,.xls"
          onChange={handleExcelUpload}
          className="hidden"
        />

        <div className="flex items-center space-x-2">
          <Button onClick={downloadTemplate} variant="outline" className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Template CSV</span>
          </Button>

          <Button onClick={downloadExcelTemplate} variant="outline" className="flex items-center space-x-2 bg-green-50 hover:bg-green-100 text-green-700 border-green-200">
            <TableIcon className="h-4 w-4" />
            <span>Template Excel</span>
          </Button>
        </div>
        
        <Button
          onClick={submitBulkData}
          disabled={isLoading || bulkData.filter(row => row.userId || row.namaRekening || row.noWa || row.kataKata).length === 0}
          className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700"
        >
          <Save className="h-4 w-4" />
          <span>{isLoading ? "Menyimpan..." : "Simpan Data"}</span>
        </Button>
      </div>

      {/* CSV Input Section */}
      {showCsvInput && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>Import dari CSV (Manual Paste)</span>
            </CardTitle>
            <p className="text-sm text-gray-600 mt-2">
              Untuk import file Excel (.xlsx/.xls), gunakan tombol \"Import Excel\" yang lebih mudah dan cepat
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="csv-input">Paste data CSV (Tanggal, User ID, Nama Rekening, No WA, Kata Kata)</Label>
              <Textarea
                id="csv-input"
                placeholder="2024-01-01,USER001,John Doe,08123456789,Halo selamat pagi&#10;2024-01-01,USER002,Jane Smith,08234567890,Selamat siang"
                value={csvInput}
                onChange={(e) => setCsvInput(e.target.value)}
                rows={6}
                className="mt-2"
              />
            </div>
            <div className="flex space-x-3">
              <Button onClick={parseCsvInput} disabled={!csvInput.trim()}>
                Import Data
              </Button>
              <Button variant="outline" onClick={() => setShowCsvInput(false)}>
                Batal
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Data Entry Table - Spreadsheet Style */}
      <Card>
        <CardHeader>
          <CardTitle>Input Data Follow Up</CardTitle>
          <p className="text-sm text-gray-600">Masukkan data pelanggan dalam format spreadsheet</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 px-3 py-2 text-center font-medium text-gray-700 w-12">
                    #
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left font-medium text-gray-700">
                    Tanggal
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left font-medium text-gray-700">
                    User ID
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left font-medium text-gray-700">
                    Nama Rekening
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left font-medium text-gray-700">
                    No WhatsApp
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-left font-medium text-gray-700">
                    Kata Kata
                  </th>
                  <th className="border border-gray-300 px-3 py-2 text-center font-medium text-gray-700 w-20">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody>
                {bulkData.map((row, index) => (
                  <tr key={row.id} className="hover:bg-blue-50">
                    <td className="border border-gray-300 px-3 py-1 text-center text-sm bg-gray-50 font-medium text-gray-600">
                      {index + 1}
                    </td>
                    <td className="border border-gray-300 px-1 py-1">
                      <Input
                        type="date"
                        value={row.tanggal}
                        onChange={(e) => updateRow(row.id, 'tanggal', e.target.value)}
                        className="w-full border-0 focus:ring-1 focus:ring-blue-500 text-sm"
                      />
                    </td>
                    <td className="border border-gray-300 px-1 py-1">
                      <Input
                        value={row.userId}
                        onChange={(e) => updateRow(row.id, 'userId', e.target.value)}
                        placeholder="naafi44"
                        className="w-full border-0 focus:ring-1 focus:ring-blue-500 text-sm"
                      />
                    </td>
                    <td className="border border-gray-300 px-1 py-1">
                      <Input
                        value={row.namaRekening}
                        onChange={(e) => updateRow(row.id, 'namaRekening', e.target.value)}
                        placeholder="naafi irfan jamiel"
                        className="w-full border-0 focus:ring-1 focus:ring-blue-500 text-sm"
                      />
                    </td>
                    <td className="border border-gray-300 px-1 py-1">
                      <Input
                        value={row.noWa}
                        onChange={(e) => updateRow(row.id, 'noWa', e.target.value)}
                        placeholder="628515956331"
                        className="w-full border-0 focus:ring-1 focus:ring-blue-500 text-sm"
                      />
                    </td>
                    <td className="border border-gray-300 px-1 py-1">
                      <Input
                        value={row.kataKata}
                        onChange={(e) => updateRow(row.id, 'kataKata', e.target.value)}
                        placeholder="selamat datang"
                        className="w-full border-0 focus:ring-1 focus:ring-blue-500 text-sm"
                      />
                    </td>
                    <td className="border border-gray-300 px-1 py-1 text-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeRow(row.id)}
                        className="text-red-600 hover:text-red-800 hover:bg-red-50 h-8 w-8 p-0"
                        title="Hapus baris"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
            <div className="text-sm text-blue-800">
              <p className="font-medium mb-1">Informasi Penting:</p>
              <ul className="space-y-1 list-disc list-inside">
                <li><strong>Import Excel:</strong> Upload file .xlsx/.xls dengan 5 kolom (Tanggal, User ID, Nama, No WA, Kata Kata)</li>
                <li><strong>Import CSV:</strong> Paste data CSV atau upload file dengan format yang sama</li>
                <li>Status WhatsApp dan Nama CS akan diisi kosong dan bisa diperbarui di halaman Database</li>
                <li>Format tanggal menggunakan format YYYY-MM-DD atau format Excel</li>
                <li>Kata kata akan digunakan untuk membuat link WhatsApp langsung</li>
                <li>Pastikan semua field terisi dengan benar sebelum menyimpan</li>
                <li>Data yang sudah disimpan dapat diedit melalui halaman Database</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
