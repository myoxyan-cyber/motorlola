import { useEffect, useState, useRef } from 'react';

interface Bubble {
  id: number;
  x: number;
  y: number;
  size: number;
  speed: number;
  opacity: number;
  color: string;
  drift: number;
  time: number;
  phase: number;
}

interface BubbleEffectProps {
  enabled: boolean;
}

const colors = [
  'rgba(59, 130, 246, 0.25)', // blue
  'rgba(147, 51, 234, 0.25)', // purple
  'rgba(16, 185, 129, 0.25)', // emerald
  'rgba(245, 158, 11, 0.25)', // amber
  'rgba(239, 68, 68, 0.25)',  // red
  'rgba(6, 182, 212, 0.25)',  // cyan
  'rgba(168, 85, 247, 0.25)', // violet
  'rgba(34, 197, 94, 0.25)',  // green
  'rgba(251, 113, 133, 0.25)', // rose
  'rgba(14, 165, 233, 0.25)', // sky
];

export default function BubbleEffect({ enabled }: BubbleEffectProps) {
  const [bubbles, setBubbles] = useState<Bubble[]>([]);
  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);

  useEffect(() => {
    if (!enabled) {
      setBubbles([]);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }

    // Create initial bubbles with enhanced properties
    const initialBubbles: Bubble[] = [];
    for (let i = 0; i < 10; i++) {
      initialBubbles.push({
        id: i,
        x: Math.random() * 256, // sidebar width
        y: Math.random() * window.innerHeight,
        size: Math.random() * 50 + 30, // 30-80px (slightly larger)
        speed: Math.random() * 1.5 + 0.8, // 0.8-2.3px per frame (more consistent)
        opacity: Math.random() * 0.3 + 0.4, // 0.4-0.7 (more visible)
        color: colors[Math.floor(Math.random() * colors.length)],
        drift: Math.random() * 0.8 - 0.4, // -0.4 to 0.4 horizontal drift
        time: 0,
        phase: Math.random() * Math.PI * 2, // Random phase for sine wave
      });
    }
    setBubbles(initialBubbles);

    const animate = (currentTime: number) => {
      if (lastTimeRef.current === 0) {
        lastTimeRef.current = currentTime;
      }

      const deltaTime = (currentTime - lastTimeRef.current) / 16.67; // Normalize to ~60fps
      lastTimeRef.current = currentTime;

      setBubbles(prevBubbles =>
        prevBubbles.map(bubble => {
          const newTime = bubble.time + deltaTime * 0.02;

          // Smooth sine wave movement for horizontal drift
          const horizontalOffset = Math.sin(newTime + bubble.phase) * 15;
          const newX = bubble.x + bubble.drift * deltaTime + horizontalOffset * 0.1;

          // Smooth vertical movement
          const newY = bubble.y - bubble.speed * deltaTime;

          // Reset bubble when it goes off screen
          if (newY + bubble.size < -50) {
            return {
              ...bubble,
              x: Math.random() * 256,
              y: window.innerHeight + bubble.size + Math.random() * 100,
              size: Math.random() * 50 + 30,
              speed: Math.random() * 1.5 + 0.8,
              opacity: Math.random() * 0.3 + 0.4,
              color: colors[Math.floor(Math.random() * colors.length)],
              drift: Math.random() * 0.8 - 0.4,
              time: 0,
              phase: Math.random() * Math.PI * 2,
            };
          }

          // Keep bubbles within sidebar bounds
          const clampedX = Math.max(0, Math.min(256 - bubble.size, newX));

          return {
            ...bubble,
            x: clampedX,
            y: newY,
            time: newTime,
          };
        })
      );

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [enabled]);

  if (!enabled) return null;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {bubbles.map(bubble => {
        const pulsateScale = 1 + Math.sin(bubble.time + bubble.phase) * 0.05;
        const dynamicOpacity = bubble.opacity + Math.sin(bubble.time * 0.5 + bubble.phase) * 0.1;

        return (
          <div
            key={bubble.id}
            className="absolute rounded-full will-change-transform"
            style={{
              transform: `translate3d(${bubble.x}px, ${bubble.y}px, 0) scale(${pulsateScale})`,
              width: `${bubble.size}px`,
              height: `${bubble.size}px`,
              opacity: Math.max(0.2, Math.min(0.8, dynamicOpacity)),
              background: `radial-gradient(circle at 35% 35%, ${bubble.color.replace('0.25', '0.7')}, ${bubble.color.replace('0.25', '0.15')})`,
              boxShadow: `
                0 0 ${bubble.size * 1.2}px ${bubble.color.replace('0.25', '0.3')},
                inset 0 0 ${bubble.size * 0.4}px ${bubble.color.replace('0.25', '0.25')},
                0 0 ${bubble.size * 0.6}px ${bubble.color.replace('0.25', '0.2')}
              `,
              filter: `blur(${Math.max(0, Math.sin(bubble.time * 0.3) * 0.5)}px)`,
              backfaceVisibility: 'hidden',
              perspective: '1000px',
            }}
          />
        );
      })}
    </div>
  );
}
