#!/bin/bash

echo "🚀 Starting deployment to Niagahoster VPS..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if .env exists
if [ ! -f .env ]; then
    echo -e "${RED}Error: .env file not found!${NC}"
    echo "Please create .env file with your environment variables"
    exit 1
fi

# Create logs directory
mkdir -p logs

# Build the application
echo -e "${YELLOW}Building application...${NC}"
npm run build

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Build successful!${NC}"
else
    echo -e "${RED}❌ Build failed!${NC}"
    exit 1
fi

# Start with PM2
echo -e "${YELLOW}Starting application with PM2...${NC}"
pm2 start ecosystem.config.js

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Application started successfully!${NC}"
    echo -e "${GREEN}Application is running on port 3000${NC}"
    echo -e "${YELLOW}Use 'pm2 status' to check status${NC}"
    echo -e "${YELLOW}Use 'pm2 logs followup-manager' to view logs${NC}"
else
    echo -e "${RED}❌ Failed to start application!${NC}"
    exit 1
fi

echo -e "${GREEN}🎉 Deployment completed!${NC}"
