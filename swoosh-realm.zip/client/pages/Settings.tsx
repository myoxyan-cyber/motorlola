import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useSettings } from "@/contexts/SettingsContext";
import { toast } from "sonner";
import {
  Settings as SettingsIcon,
  Sun,
  Moon,
  Type,
  Image,
  Sparkles,
  RotateCcw,
  Save,
  Palette,
  Monitor,
  Eye
} from "lucide-react";

const fontOptions = [
  { value: 'inter', label: 'Inter (Default)', preview: 'font-sans' },
  { value: 'roboto', label: 'Roboto', preview: 'font-mono' },
  { value: 'poppins', label: 'Poppins', preview: 'font-serif' },
  { value: 'open-sans', label: 'Open Sans', preview: 'font-sans' },
];

const backgroundImages = [
  { url: '/placeholder.svg', name: 'Default' },
  { url: 'https://images.unsplash.com/photo-1519681393784-d120c3b9aff8?w=800', name: 'Mountain View' },
  { url: 'https://images.unsplash.com/photo-1464822759844-d150165c99fd?w=800', name: 'Forest' },
  { url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800', name: 'Ocean' },
  { url: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800', name: 'Abstract Blue' },
  { url: 'https://images.unsplash.com/photo-1557683316-973673baf926?w=800', name: 'Abstract Purple' },
];

export default function Settings() {
  const {
    theme,
    setTheme,
    fontFamily,
    setFontFamily,
    brandName,
    setBrandName,
    loginBackgroundImage,
    setLoginBackgroundImage,
    sidebarBubbleEffect,
    setSidebarBubbleEffect,
    resetToDefaults
  } = useSettings();

  const [tempBrandName, setTempBrandName] = useState(brandName);
  const [customImageUrl, setCustomImageUrl] = useState('');

  const handleSaveBrandName = () => {
    if (tempBrandName.trim()) {
      setBrandName(tempBrandName.trim());
      toast.success("Nama brand berhasil disimpan");
    } else {
      toast.error("Nama brand tidak boleh kosong");
    }
  };

  const handleAddCustomImage = () => {
    if (customImageUrl.trim()) {
      setLoginBackgroundImage(customImageUrl.trim());
      setCustomImageUrl('');
      toast.success("Background custom berhasil diterapkan");
    } else {
      toast.error("URL gambar tidak boleh kosong");
    }
  };

  const handleResetSettings = () => {
    if (confirm("Apakah Anda yakin ingin mereset semua pengaturan ke default?")) {
      resetToDefaults();
      setTempBrandName('FU Manager');
      toast.success("Pengaturan berhasil direset ke default");
    }
  };

  return (
    <div className="p-8 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center space-x-3">
            <SettingsIcon className="h-8 w-8 text-blue-600" />
            <span>Pengaturan</span>
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Kustomisasi tampilan dan pengalaman aplikasi Anda</p>
        </div>
        <Button 
          onClick={handleResetSettings}
          variant="outline" 
          className="flex items-center space-x-2 text-red-600 hover:text-red-800 border-red-200 hover:bg-red-50"
        >
          <RotateCcw className="h-4 w-4" />
          <span>Reset ke Default</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Theme Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Palette className="h-5 w-5 text-blue-600" />
              <span>Tema Tampilan</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label className="text-sm font-medium">Mode Tema</Label>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant={theme === 'light' ? 'default' : 'outline'}
                  onClick={() => setTheme('light')}
                  className="justify-start space-x-2 h-12"
                >
                  <Sun className="h-4 w-4" />
                  <span>Light Mode</span>
                </Button>
                <Button
                  variant={theme === 'dark' ? 'default' : 'outline'}
                  onClick={() => setTheme('dark')}
                  className="justify-start space-x-2 h-12"
                >
                  <Moon className="h-4 w-4" />
                  <span>Dark Mode</span>
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">Status Tema</Label>
              <div className="flex items-center space-x-2">
                <Monitor className="h-4 w-4 text-gray-500" />
                <Badge variant={theme === 'dark' ? 'default' : 'secondary'}>
                  {theme === 'dark' ? 'Dark Mode Aktif' : 'Light Mode Aktif'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Font Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Type className="h-5 w-5 text-green-600" />
              <span>Pengaturan Font</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label htmlFor="font-family" className="text-sm font-medium">Font Family</Label>
              <Select value={fontFamily} onValueChange={setFontFamily}>
                <SelectTrigger id="font-family">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {fontOptions.map((font) => (
                    <SelectItem key={font.value} value={font.value}>
                      <div className="flex items-center space-x-2">
                        <span className={font.preview}>{font.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">Preview Font</Label>
              <div className="p-4 border rounded-lg bg-gray-50 dark:bg-gray-800">
                <p className="text-lg font-medium mb-2">Follow Up Manager</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Kelola data follow up pelanggan dengan mudah dan efisien.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Brand Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-purple-600" />
              <span>Pengaturan Brand</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Label htmlFor="brand-name" className="text-sm font-medium">Nama Brand</Label>
              <div className="flex space-x-2">
                <Input
                  id="brand-name"
                  value={tempBrandName}
                  onChange={(e) => setTempBrandName(e.target.value)}
                  placeholder="Masukkan nama brand"
                  className="flex-1"
                />
                <Button onClick={handleSaveBrandName} size="sm">
                  <Save className="h-4 w-4 mr-1" />
                  Simpan
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium">Preview Brand</Label>
              <div className="p-4 border rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900 dark:to-purple-900">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <SettingsIcon className="h-5 w-5 text-white" />
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 dark:text-white">{brandName}</h2>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Visual Effects */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-orange-600" />
              <span>Efek Visual</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Efek Gelembung Sidebar</Label>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Tampilkan animasi gelembung bergerak di sidebar
                </p>
              </div>
              <Switch
                checked={sidebarBubbleEffect}
                onCheckedChange={setSidebarBubbleEffect}
              />
            </div>

            <Separator />

            <div className="space-y-3">
              <Label className="text-sm font-medium">Status Efek</Label>
              <div className="flex items-center space-x-2">
                <Sparkles className="h-4 w-4 text-orange-500" />
                <Badge variant={sidebarBubbleEffect ? 'default' : 'secondary'}>
                  {sidebarBubbleEffect ? 'Efek Gelembung Aktif' : 'Efek Gelembung Nonaktif'}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Login Background Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center space-x-2">
            <Image className="h-5 w-5 text-indigo-600" />
            <span>Background Login</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Predefined Images */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Background Tersedia</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {backgroundImages.map((bg, index) => (
                <div key={index} className="space-y-2">
                  <div
                    className={`relative aspect-video rounded-lg overflow-hidden cursor-pointer border-2 transition-all ${
                      loginBackgroundImage === bg.url
                        ? 'border-blue-500 ring-2 ring-blue-200'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setLoginBackgroundImage(bg.url)}
                  >
                    <img
                      src={bg.url}
                      alt={bg.name}
                      className="w-full h-full object-cover"
                    />
                    {loginBackgroundImage === bg.url && (
                      <div className="absolute inset-0 bg-blue-500 bg-opacity-20 flex items-center justify-center">
                        <Eye className="h-6 w-6 text-white" />
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-center text-gray-600 dark:text-gray-400">{bg.name}</p>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Custom Image URL */}
          <div className="space-y-3">
            <Label htmlFor="custom-bg" className="text-sm font-medium">Background Custom (URL)</Label>
            <div className="flex space-x-2">
              <Input
                id="custom-bg"
                value={customImageUrl}
                onChange={(e) => setCustomImageUrl(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="flex-1"
              />
              <Button onClick={handleAddCustomImage} size="sm">
                <Image className="h-4 w-4 mr-1" />
                Terapkan
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Masukkan URL gambar untuk background login kustom
            </p>
          </div>

          {/* Current Background Preview */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Preview Background Aktif</Label>
            <div className="relative aspect-video max-w-md rounded-lg overflow-hidden border">
              <img
                src={loginBackgroundImage}
                alt="Current background"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                <div className="text-center text-white">
                  <h3 className="text-lg font-bold">{brandName}</h3>
                  <p className="text-sm opacity-90">Login Background Preview</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
