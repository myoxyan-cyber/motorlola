import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import { useSettings } from "@/contexts/SettingsContext";
import { Button } from "@/components/ui/button";
import BubbleEffect from "@/components/BubbleEffect";
import {
  LayoutDashboard,
  Plus,
  Database,
  Users,
  Settings,
  BarChart3,
  LogOut,
  Shield,
  User
} from "lucide-react";

const navigation = [
  {
    name: "Dashboard",
    href: "/",
    icon: LayoutDashboard,
  },
  {
    name: "Tambah Data",
    href: "/add-data",
    icon: Plus,
  },
  {
    name: "Database FU",
    href: "/database",
    icon: Database,
  },
  {
    name: "Laporan",
    href: "/reports",
    icon: BarChart3,
  },
  {
    name: "CS Management",
    href: "/cs-management",
    icon: Users,
  },
  {
    name: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export default function Sidebar() {
  const location = useLocation();
  const { user, logout } = useAuth();
  const { brandName, sidebarBubbleEffect } = useSettings();

  const handleLogout = () => {
    if (confirm('Apakah Anda yakin ingin logout?')) {
      logout();
    }
  };

  return (
    <div className="flex h-screen w-64 flex-col bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 relative overflow-hidden">
      {/* Bubble Effect */}
      <BubbleEffect enabled={sidebarBubbleEffect} />

      {/* Logo */}
      <div className="flex h-16 items-center px-6 border-b border-gray-200 dark:border-gray-700 relative z-10">
        <div className="flex items-center space-x-2">
          <div className="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
            <Database className="h-5 w-5 text-white" />
          </div>
          <h1 className="text-xl font-bold text-gray-900 dark:text-white">{brandName}</h1>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2 relative z-10">
        {navigation.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.name}
              to={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 backdrop-blur-sm",
                isActive
                  ? "bg-blue-50 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 border-r-2 border-blue-700 shadow-lg"
                  : "text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 hover:text-gray-900 dark:hover:text-white hover:shadow-md"
              )}
            >
              <item.icon className={cn(
                "h-5 w-5 transition-colors",
                isActive ? "text-blue-700 dark:text-blue-300" : "text-gray-400 dark:text-gray-500"
              )} />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      {/* User Info */}
      <div className="border-t border-gray-200 dark:border-gray-700 p-4 space-y-3 relative z-10 backdrop-blur-sm">
        <div className="flex items-center space-x-3">
          <div className={cn(
            "h-8 w-8 rounded-full flex items-center justify-center shadow-md",
            user?.role === 'admin' ? 'bg-red-100 dark:bg-red-900/50' : 'bg-blue-100 dark:bg-blue-900/50'
          )}>
            {user?.role === 'admin' ? (
              <Shield className="h-4 w-4 text-red-600" />
            ) : (
              <User className="h-4 w-4 text-blue-600" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">
              {user?.name || 'User'}
            </p>
            <p className="text-xs text-gray-500 truncate">
              @{user?.username} • {user?.role}
            </p>
          </div>
        </div>

        <Button
          onClick={handleLogout}
          variant="outline"
          size="sm"
          className="w-full justify-start text-red-600 hover:text-red-800 hover:bg-red-50 border-red-200"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}
