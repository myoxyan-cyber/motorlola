import { RequestHandler } from "express";
import { supabase } from "../lib/supabase";
import { z } from "zod";
import bcrypt from "bcrypt";

// Validation schemas
const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Helper function to convert database row to user object
const convertToUser = (row: any) => ({
  id: row.id,
  username: row.username,
  name: row.name,
  role: row.role,
});

// Login endpoint
export const login: RequestHandler = async (req, res) => {
  try {
    console.log('Login request received:', {
      body: req.body,
      contentType: req.headers['content-type'],
      method: req.method
    });

    const validatedData = loginSchema.parse(req.body);
    
    // Get user from database
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', validatedData.username)
      .single();

    if (error || !user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password'
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(validatedData.password, user.password_hash);
    
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password'
      });
    }

    // Return user data (without password)
    const userData = convertToUser(user);
    
    res.json({
      success: true,
      user: userData,
      message: 'Login successful'
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Validation error in login:', error.errors);
      return res.status(400).json({
        success: false,
        message: 'Validation error: ' + error.errors.map(e => e.message).join(', ')
      });
    }

    // Check if it's a body parsing error
    if (error instanceof SyntaxError && 'body' in error) {
      console.error('Body parsing error:', error);
      return res.status(400).json({
        success: false,
        message: 'Invalid JSON in request body'
      });
    }

    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error: ' + (error as Error).message
    });
  }
};

// Verify token/session endpoint (placeholder for now)
export const verifySession: RequestHandler = async (req, res) => {
  // For now, we'll just return success since we're using localStorage
  // In a production app, you'd verify JWT tokens here
  res.json({
    success: true,
    message: 'Session valid'
  });
};
