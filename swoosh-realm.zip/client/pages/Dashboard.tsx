import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  TrendingUp,
  Database,
  Phone,
  MessageSquare
} from "lucide-react";
import { DashboardStats } from "@shared/followup";

const StatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendValue,
  color = "blue" 
}: {
  title: string;
  value: string | number;
  icon: any;
  trend?: "up" | "down";
  trendValue?: string;
  color?: "blue" | "green" | "red" | "yellow" | "purple";
}) => {
  const colorClasses = {
    blue: "bg-blue-50 border-blue-200 text-blue-800",
    green: "bg-green-50 border-green-200 text-green-800", 
    red: "bg-red-50 border-red-200 text-red-800",
    yellow: "bg-yellow-50 border-yellow-200 text-yellow-800",
    purple: "bg-purple-50 border-purple-200 text-purple-800"
  };

  const iconColorClasses = {
    blue: "text-blue-600",
    green: "text-green-600",
    red: "text-red-600", 
    yellow: "text-yellow-600",
    purple: "text-purple-600"
  };

  return (
    <Card className={`${colorClasses[color]} border-2`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-5 w-5 ${iconColorClasses[color]}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {trend && trendValue && (
          <div className="flex items-center text-xs text-muted-foreground mt-1">
            <TrendingUp className={`h-3 w-3 mr-1 ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`} />
            <span>{trendValue}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch('/api/dashboard/stats');
        const data = await response.json();
        setStats(data);
      } catch (error) {
        console.error('Error fetching stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Overview data follow-up pelanggan</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
            Online
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Data"
          value={stats?.totalRecords || 0}
          icon={Database}
          color="blue"
          trend="up"
          trendValue="+12% dari minggu lalu"
        />
        <StatCard
          title="WhatsApp Aktif"
          value={stats?.activeWa || 0}
          icon={CheckCircle}
          color="green"
          trend="up"
          trendValue="+8% dari minggu lalu"
        />
        <StatCard
          title="WhatsApp Tidak Aktif"
          value={stats?.inactiveWa || 0}
          icon={XCircle}
          color="red"
          trend="down"
          trendValue="-5% dari minggu lalu"
        />
        <StatCard
          title="Pending Follow Up"
          value={stats?.pendingFollowUp || 0}
          icon={Clock}
          color="yellow"
          trend="down"
          trendValue="-3% dari minggu lalu"
        />
      </div>

      {/* Additional Info Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              <span>Aktivitas Hari Ini</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div>
                    <p className="font-medium text-sm">Follow Up Selesai</p>
                    <p className="text-xs text-gray-500">Hari ini</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-green-600">
                  {stats?.completedToday || 0}
                </span>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div>
                    <p className="font-medium text-sm">Data Baru Ditambahkan</p>
                    <p className="text-xs text-gray-500">Hari ini</p>
                  </div>
                </div>
                <span className="text-lg font-bold text-blue-600">
                  0
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-purple-600" />
              <span>Quick Actions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <button className="w-full p-3 bg-blue-50 hover:bg-blue-100 rounded-lg text-left transition-colors">
                <div className="flex items-center space-x-3">
                  <Users className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium text-sm">Tambah Data Baru</p>
                    <p className="text-xs text-gray-500">Import data pelanggan</p>
                  </div>
                </div>
              </button>
              
              <button className="w-full p-3 bg-green-50 hover:bg-green-100 rounded-lg text-left transition-colors">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="font-medium text-sm">Update Status WA</p>
                    <p className="text-xs text-gray-500">Perbarui status whatsapp</p>
                  </div>
                </div>
              </button>
              
              <button className="w-full p-3 bg-purple-50 hover:bg-purple-100 rounded-lg text-left transition-colors">
                <div className="flex items-center space-x-3">
                  <Database className="h-5 w-5 text-purple-600" />
                  <div>
                    <p className="font-medium text-sm">Lihat Database</p>
                    <p className="text-xs text-gray-500">Kelola data follow up</p>
                  </div>
                </div>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Ringkasan Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {Math.round(((stats?.activeWa || 0) / Math.max(stats?.totalRecords || 1, 1)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">WA Aktif</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                {Math.round(((stats?.inactiveWa || 0) / Math.max(stats?.totalRecords || 1, 1)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">WA Tidak Aktif</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">
                {Math.round(((stats?.pendingFollowUp || 0) / Math.max(stats?.totalRecords || 1, 1)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">Pending FU</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {Math.round((((stats?.totalRecords || 0) - (stats?.pendingFollowUp || 0)) / Math.max(stats?.totalRecords || 1, 1)) * 100)}%
              </div>
              <div className="text-sm text-gray-600">FU Selesai</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
