# 🚀 Quick Setup untuk Niagahoster VPS

## ✅ Files Yang Perlu Diupload

Setelah build selesai, upload files ini ke VPS Niagahoster:

### 📁 Struktur Files:
```
/var/www/followup-manager/
├── dist/                 # Hasil build (WAJIB)
│   ├── spa/             # Frontend files  
│   └── server/          # Backend files
├── node_modules/        # Dependencies (install di VPS)
├── package.json         # Package info
├── ecosystem.config.js  # PM2 config
├── deploy.sh           # Deployment script
└── .env                # Environment variables (BUAT MANUAL)
```

## 🏃‍♂️ Quick Start Commands

### 1. Di VPS Niagahoster:
```bash
# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 dan Nginx
sudo npm install -g pm2
sudo apt install nginx -y

# Buat folder project
sudo mkdir -p /var/www/followup-manager
cd /var/www/followup-manager
```

### 2. Upload Files:
- Upload semua files project ke `/var/www/followup-manager/`
- Atau gunakan FileZilla/SCP

### 3. Setup Environment:
```bash
# Buat file .env
nano .env
```

Copy paste ini ke file .env:
```env
NODE_ENV=production
PORT=3000
SUPABASE_URL=https://uzdbsesnrckllmfgqalt.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV6ZGJzZXNucmNrbGxtZmdxYWx0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY5NDg3MTMsImV4cCI6MjA3MjUyNDcxM30.x3RbgGy-ryZfWvZO_LAVbK7moiWinXTwDIcTd2B4-kA
```

### 4. Install & Start:
```bash
# Install dependencies
npm install --production

# Buat folder logs
mkdir logs

# Start dengan PM2
pm2 start ecosystem.config.js

# Auto start saat reboot
pm2 startup
pm2 save
```

### 5. Setup Nginx (ganti `yourdomain.com`):
```bash
sudo nano /etc/nginx/sites-available/followup-manager
```

Config Nginx:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    location / {
        root /var/www/followup-manager/dist/spa;
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/followup-manager /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## ✅ Verifikasi

1. **Cek PM2**: `pm2 status`
2. **Cek Logs**: `pm2 logs followup-manager`  
3. **Test API**: `curl http://localhost:3000/api/ping`
4. **Akses Website**: Buka domain Anda

## 🆘 Troubleshooting

### Aplikasi tidak jalan:
```bash
pm2 logs followup-manager --lines 50
```

### Nginx error:
```bash
sudo tail -f /var/log/nginx/error.log
```

### Restart semua:
```bash
pm2 restart followup-manager
sudo systemctl restart nginx
```

## 🔒 SSL Certificate (Opsional)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

---

## 📞 Butuh Bantuan?

Jika ada error, kirim output dari:
- `pm2 status`
- `pm2 logs followup-manager`
- `sudo systemctl status nginx`

**Selamat! Aplikasi Follow Up Manager siap digunakan di domain Anda! 🎉**
