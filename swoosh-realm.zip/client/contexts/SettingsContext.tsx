import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type ThemeMode = 'light' | 'dark';
export type FontFamily = 'inter' | 'roboto' | 'poppins' | 'open-sans';

interface SettingsContextType {
  // Theme
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  
  // Font
  fontFamily: FontFamily;
  setFontFamily: (font: FontFamily) => void;
  
  // Brand
  brandName: string;
  setBrandName: (name: string) => void;
  
  // Login customization
  loginBackgroundImage: string;
  setLoginBackgroundImage: (url: string) => void;
  
  // Sidebar effects
  sidebarBubbleEffect: boolean;
  setSidebarBubbleEffect: (enabled: boolean) => void;
  
  // Reset to defaults
  resetToDefaults: () => void;
}

const defaultSettings = {
  theme: 'light' as ThemeMode,
  fontFamily: 'inter' as FontFamily,
  brandName: 'FU Manager',
  loginBackgroundImage: '/placeholder.svg',
  sidebarBubbleEffect: true,
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};

interface SettingsProviderProps {
  children: ReactNode;
}

export const SettingsProvider: React.FC<SettingsProviderProps> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(defaultSettings.theme);
  const [fontFamily, setFontFamilyState] = useState<FontFamily>(defaultSettings.fontFamily);
  const [brandName, setBrandNameState] = useState<string>(defaultSettings.brandName);
  const [loginBackgroundImage, setLoginBackgroundImageState] = useState<string>(defaultSettings.loginBackgroundImage);
  const [sidebarBubbleEffect, setSidebarBubbleEffectState] = useState<boolean>(defaultSettings.sidebarBubbleEffect);

  // Load settings from localStorage on mount
  useEffect(() => {
    const loadSettings = () => {
      try {
        const savedSettings = localStorage.getItem('app_settings');
        if (savedSettings) {
          const settings = JSON.parse(savedSettings);
          setThemeState(settings.theme || defaultSettings.theme);
          setFontFamilyState(settings.fontFamily || defaultSettings.fontFamily);
          setBrandNameState(settings.brandName || defaultSettings.brandName);
          setLoginBackgroundImageState(settings.loginBackgroundImage || defaultSettings.loginBackgroundImage);
          setSidebarBubbleEffectState(settings.sidebarBubbleEffect ?? defaultSettings.sidebarBubbleEffect);
        }
      } catch (error) {
        console.error('Error loading settings:', error);
      }
    };

    loadSettings();
  }, []);

  // Save settings to localStorage whenever they change
  const saveSettings = (newSettings: any) => {
    try {
      localStorage.setItem('app_settings', JSON.stringify(newSettings));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    const settings = {
      theme: newTheme,
      fontFamily,
      brandName,
      loginBackgroundImage,
      sidebarBubbleEffect,
    };
    saveSettings(settings);
    
    // Apply theme to document
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const setFontFamily = (newFont: FontFamily) => {
    setFontFamilyState(newFont);
    const settings = {
      theme,
      fontFamily: newFont,
      brandName,
      loginBackgroundImage,
      sidebarBubbleEffect,
    };
    saveSettings(settings);
    
    // Apply font to document
    document.documentElement.setAttribute('data-font', newFont);
  };

  const setBrandName = (newName: string) => {
    setBrandNameState(newName);
    const settings = {
      theme,
      fontFamily,
      brandName: newName,
      loginBackgroundImage,
      sidebarBubbleEffect,
    };
    saveSettings(settings);
  };

  const setLoginBackgroundImage = (newUrl: string) => {
    setLoginBackgroundImageState(newUrl);
    const settings = {
      theme,
      fontFamily,
      brandName,
      loginBackgroundImage: newUrl,
      sidebarBubbleEffect,
    };
    saveSettings(settings);
  };

  const setSidebarBubbleEffect = (enabled: boolean) => {
    setSidebarBubbleEffectState(enabled);
    const settings = {
      theme,
      fontFamily,
      brandName,
      loginBackgroundImage,
      sidebarBubbleEffect: enabled,
    };
    saveSettings(settings);
  };

  const resetToDefaults = () => {
    setThemeState(defaultSettings.theme);
    setFontFamilyState(defaultSettings.fontFamily);
    setBrandNameState(defaultSettings.brandName);
    setLoginBackgroundImageState(defaultSettings.loginBackgroundImage);
    setSidebarBubbleEffectState(defaultSettings.sidebarBubbleEffect);
    
    saveSettings(defaultSettings);
    
    // Apply defaults to document
    document.documentElement.classList.remove('dark');
    document.documentElement.setAttribute('data-font', defaultSettings.fontFamily);
  };

  // Apply initial theme and font on mount
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    document.documentElement.setAttribute('data-font', fontFamily);
  }, []);

  const value = {
    theme,
    setTheme,
    fontFamily,
    setFontFamily,
    brandName,
    setBrandName,
    loginBackgroundImage,
    setLoginBackgroundImage,
    sidebarBubbleEffect,
    setSidebarBubbleEffect,
    resetToDefaults,
  };

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
};
